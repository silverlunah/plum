<!--
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 -->

<script>
	import { onMount, onDestroy } from 'svelte';
	import { fly, slide } from 'svelte/transition';
	import { io } from 'socket.io-client';
	import { SOCKET_EVENTS } from '$lib/socketEvents';
	import {
		socket,
		runnerConfig,
		panelExpanded,
		builtInEnabled,
		resolveSelectedRunners,
		triggerRun,
		cancelRun,
		reportsVersion,
		runsVersion,
		backgroundRuns,
		makeRunEntry,
		mergeRRwebBatch
	} from '$lib/stores/runner';
	import { activeProjectId } from '$lib/stores/project';
	import { auth } from '$lib/stores/auth';
	import { reportUrl } from '$lib/api/reports';
	import { fetchRunners, fetchBuiltInEnabled, pingRunner } from '$lib/api/runners';
	import { fetchRuns, fetchRun } from '$lib/api/repository';
	import { fetchIntegrations } from '$lib/api/settings';
	import { fetchActiveRuns } from '$lib/api/activeRuns';
	import {
		API_BASE,
		BROWSERS,
		BUILTIN_RUNNER_ID,
		WORKERS_MIN,
		WORKERS_MAX,
		RUN_PICKER_LIMIT,
		REDIRECT_DELAY_MS,
		TRIGGER_TYPES
	} from '$lib/constants';
	import { BUILTIN_RUNNER_LABEL, CLEAR_LABEL, DISCORD_LABEL, SLACK_LABEL } from '$lib/copy/common';
	import {
		RUN_ALL_TITLE,
		RUN_ALL_CONFIRM_LABEL,
		RUN_ALL_BODY_PREFIX,
		RUN_ALL_BODY_STRONG,
		RUN_ALL_BODY_SUFFIX,
		VIEW_REPORT_LABEL,
		TEST_RUN_LABEL,
		CLEAR_TEST_RUN_LABEL,
		NO_RUN_SELECTED_LABEL,
		NO_ACTIVE_TEST_RUNS,
		WORKERS_LABEL,
		BROWSER_LABEL,
		RUNNERS_LABEL,
		NOTIFY_LABEL,
		NO_AUTOMATED_CASES_TITLE,
		RUN_LABEL,
		MANUAL_RUN_LABEL,
		NO_TESTS_RUNNING,
		QUEUED_LABEL,
		CANCEL_RUN_LABEL,
		automatedCaseCount,
		discordNotifyTitle,
		slackNotifyTitle,
		runKindLabel,
		startedByLabel,
		collapseOrExpandLabel,
		queuePositionLabel,
		lockedRunTitle,
		OFFLINE_LABEL,
		statusLabel as computeStatusLabel,
		runnerSummary as computeRunnerSummary
	} from '$lib/copy/runners';
	import { triggerLabel, triggerVariant, mcpName } from '$lib/utils/format';
	import ConfirmModal from '$lib/components/ui/ConfirmModal.svelte';
	import Badge from '$lib/components/ui/Badge.svelte';
	import ServiceIcon from '$lib/components/icons/ServiceIcon.svelte';
	import LockIcon from '$lib/components/icons/LockIcon.svelte';
	import IconSelect from '$lib/components/ui/IconSelect.svelte';
	import { clickOutside } from '$lib/actions/clickOutside';

	let availableRunners = [];
	// Gates the builtInEnabled subscription: it must not reconcile the saved
	// selection until the real toggle state and node list have both loaded, or
	// its synchronous first fire would clobber a valid saved selection.
	let runnersReady = false;
	// { [runnerId]: 'checking' | 'up' | 'down' }, the runner list is DB-only and
	// carries no health, so its dots would otherwise always read healthy.
	let nodePings = {};
	let testRuns = [];
	let selectedRun = null; // { id, title, tags: string[] | null }
	let selectedRunLoading = false;
	let runnersOpen = false;
	let runPickOpen = false;
	let runAllModalOpen = false;
	let integrations = { discordWebhookUrl: '', slackWebhookUrl: '', notifyPublicUrl: '' };
	let notifyDiscord = false;
	let notifySlack = false;

	let _unsubConfig, _unsubExpanded, _unsubBuiltIn, _unsubActiveProject, _socket;
	let lastFinished = null; // { reportId, verdict }, most recent completed run, for the bar's View Report shortcut

	onMount(() => {
		try {
			const saved = localStorage.getItem('plum:runnerConfig');
			if (saved) runnerConfig.update((c) => ({ ...c, ...JSON.parse(saved) }));
		} catch {}
		try {
			const exp = localStorage.getItem('plum:panelExpanded');
			if (exp !== null) panelExpanded.set(exp === 'true');
		} catch {}
		// Resolve the toggle state and the node list together, then reconcile the
		// saved selection against both. Done piecemeal, a race between the two
		// fetches could re-check the built-in runner even with its toggle off.
		Promise.all([
			fetchBuiltInEnabled()
				.then((r) => r.builtInRunnerEnabled)
				.catch(() => false),
			fetchRunners()
				.then((r) => r ?? [])
				.catch(() => [])
		]).then(([enabled, runners]) => {
			availableRunners = runners;
			runnersReady = true;
			builtInEnabled.set(enabled);
			runnerConfig.update((c) => ({
				...c,
				selectedRunners: resolveSelectedRunners(
					c.selectedRunners,
					enabled,
					runners.map((r) => r.id)
				)
			}));
			pingNodes();
		});

		fetchIntegrations()
			.then((i) => (integrations = i))
			.catch(() => {});

		// Hydrate runs already queued or running on the backend (e.g. this tab just
		// loaded/refreshed), live socket events alone only reach tabs connected at
		// the moment an event fires.
		fetchActiveRuns()
			.then(({ runs }) => {
				const activeIds = new Set(runs.map((r) => r.runId));
				backgroundRuns.update((r) => {
					const next = { ...r };
					for (const { runId, projectId, projectName, kind, label, meta, status } of runs) {
						if (!next[runId])
							next[runId] = makeRunEntry({ projectId, projectName, kind, label, meta, status });
					}
					// Drop a client-side run the server no longer tracks (its node died
					// and a restart cleared it), but keep a freshly-`done` one so the
					// completion bar still shows.
					for (const [runId, entry] of Object.entries(next)) {
						if (!activeIds.has(runId) && entry.status !== 'done') delete next[runId];
					}
					return next;
				});
				if (runs.length > 0) panelExpanded.set(true);
			})
			.catch(() => {});

		_unsubConfig = runnerConfig.subscribe((v) => {
			try {
				localStorage.setItem('plum:runnerConfig', JSON.stringify(v));
			} catch {}
		});
		_unsubExpanded = panelExpanded.subscribe((v) => {
			try {
				localStorage.setItem('plum:panelExpanded', String(v));
			} catch {}
		});
		_unsubBuiltIn = builtInEnabled.subscribe((v) => {
			if (!runnersReady) return;
			runnerConfig.update((c) => ({
				...c,
				selectedRunners: resolveSelectedRunners(
					c.selectedRunners,
					v,
					availableRunners.map((r) => r.id)
				)
			}));
		});

		const s = io(API_BASE, {
			transports: ['websocket', 'polling'],
			auth: { token: auth.getToken() }
		});
		_socket = s;
		socket.set(s);

		// Join the active project's room, scopes which run streams this tab gets.
		const joinActiveProject = () =>
			s.emit(SOCKET_EVENTS.JOIN_PROJECT, { projectId: $activeProjectId });
		s.on('connect', joinActiveProject);
		_unsubActiveProject = activeProjectId.subscribe(() => s.connected && joinActiveProject());

		s.on(SOCKET_EVENTS.REPORT_READY, () => reportsVersion.update((v) => v + 1));

		function updateBgRun(runId, updater, { streamOnly = false } = {}) {
			backgroundRuns.update((r) => {
				const run = r[runId];
				if (!run) return r;
				// Server already room-scopes streams; this also covers a project switch
				// mid-run under the same tab.
				if (streamOnly && !canOpenRun(run)) return r;
				return { ...r, [runId]: updater(run) };
			});
		}

		function upsertBgRun(runId, { projectId, projectName, kind, label, meta }, status) {
			// Keep only label + project for a run the viewer can't open, drop the
			// tag / who-started-it that the socket broadcast still carries.
			const safeMeta = canOpenRun({ projectId }) ? meta : undefined;
			backgroundRuns.update((r) => ({
				...r,
				[runId]: r[runId]
					? { ...r[runId], status }
					: makeRunEntry({ projectId, projectName, kind, label, meta: safeMeta, status })
			}));
			panelExpanded.set(true);
		}

		s.on(SOCKET_EVENTS.BG_RUN_QUEUED, ({ runId, projectId, projectName, kind, label, meta }) => {
			upsertBgRun(runId, { projectId, projectName, kind, label, meta }, 'queued');
		});

		s.on(SOCKET_EVENTS.BG_RUN_START, ({ runId, projectId, projectName, kind, label, meta }) => {
			upsertBgRun(runId, { projectId, projectName, kind, label, meta }, 'running');
		});

		s.on(SOCKET_EVENTS.BG_RUN_LOG, ({ runId, log }) => {
			updateBgRun(runId, (run) => ({ ...run, output: run.output + log }), { streamOnly: true });
		});

		s.on(SOCKET_EVENTS.BG_RUN_LANES_INIT, ({ runId, lanes }) => {
			updateBgRun(
				runId,
				(run) => ({
					...run,
					lanes: lanes.map((l) => ({ ...l, status: 'running', logs: '' }))
				}),
				{ streamOnly: true }
			);
		});

		// Upsert the lane, a tab that connected mid-run (or after a refresh)
		// missed bg-run-lanes-init, so create the lane on first sight rather than
		// dropping its logs.
		function patchLane(run, laneId, patch) {
			const lanes = run.lanes.some((l) => l.id === laneId)
				? run.lanes.map((l) => (l.id === laneId ? { ...l, ...patch(l) } : l))
				: [
						...run.lanes,
						{
							id: laneId,
							name: laneId,
							testCount: 0,
							status: 'running',
							logs: '',
							...patch({ logs: '' })
						}
					];
			return { ...run, lanes };
		}

		s.on(SOCKET_EVENTS.BG_RUN_LANE_LOG, ({ runId, laneId, log }) => {
			updateBgRun(runId, (run) => patchLane(run, laneId, (l) => ({ logs: (l.logs || '') + log })), {
				streamOnly: true
			});
		});

		s.on(SOCKET_EVENTS.BG_RUN_LANE_STATUS, ({ runId, laneId, status }) => {
			updateBgRun(runId, (run) => patchLane(run, laneId, () => ({ status })), { streamOnly: true });
		});

		s.on(SOCKET_EVENTS.BG_RUN_LANE_RRWEB_BATCH, ({ runId, ...batch }) => {
			updateBgRun(
				runId,
				(run) => ({
					...run,
					rrwebByLane: mergeRRwebBatch(run.rrwebByLane, batch)
				}),
				{ streamOnly: true }
			);
		});

		s.on(SOCKET_EVENTS.BG_RUN_DONE, ({ runId, code, reportId }) => {
			const passed = code === 0 || code === null;
			const cancelled = code === 130;
			updateBgRun(runId, (run) => ({
				...run,
				status: 'done',
				testCompleted: !cancelled,
				latestReportId: cancelled ? null : reportId,
				verdict: cancelled ? 'cancelled' : passed ? 'pass' : 'fail'
			}));
			if (!cancelled && reportId) lastFinished = { reportId, verdict: passed ? 'pass' : 'fail' };
			if (!cancelled) reportsVersion.update((v) => v + 1);
			// Keep the finished entry around briefly so a viewer on /live/<id> still
			// sees the completion bar/redirect, then drop it from the bottom bar.
			setTimeout(() => {
				backgroundRuns.update((r) => {
					const next = { ...r };
					delete next[runId];
					return next;
				});
			}, REDIRECT_DELAY_MS + 5000);
		});
	});

	onDestroy(() => {
		_unsubConfig?.();
		_unsubExpanded?.();
		_unsubBuiltIn?.();
		_unsubActiveProject?.();
		_socket?.disconnect();
	});

	$: cfg = $runnerConfig;

	$: activeRunEntries = Object.entries($backgroundRuns).filter(
		([, r]) => r.status === 'queued' || r.status === 'running'
	);
	// A run is openable only when it belongs to the project the viewer is currently
	// in. Runs from other projects still show in the bar for awareness, but you
	// have to switch to that project to open one, even if you're a member.
	$: canOpenRun = (run) => run.projectId == null || run.projectId === $activeProjectId;
	$: runningCount = activeRunEntries.filter(([, r]) => r.status === 'running').length;
	$: queuedCount = activeRunEntries.filter(([, r]) => r.status === 'queued').length;
	$: anyRunning = activeRunEntries.length > 0;

	$: if ($runsVersion >= 0)
		fetchRuns({ limit: RUN_PICKER_LIMIT })
			.then((r) => (testRuns = r.runs))
			.catch(() => {});

	$: statusColor =
		runningCount > 0
			? 'var(--accent)'
			: queuedCount > 0
				? 'var(--warn)'
				: lastFinished?.verdict === 'pass'
					? 'var(--pass)'
					: lastFinished?.verdict === 'fail'
						? 'var(--fail)'
						: 'var(--border)';

	$: statusLabel = computeStatusLabel({
		running: runningCount,
		queued: queuedCount,
		verdict: lastFinished?.verdict
	});

	$: runnerSummary = computeRunnerSummary(cfg, availableRunners);

	async function selectRun(run) {
		runPickOpen = false;
		selectedRun = { id: run.id, title: run.title, tags: null };
		selectedRunLoading = true;
		try {
			const full = await fetchRun(run.id);
			const tags = full.entries
				.filter((e) => e.case?.isAutomated)
				.map((e) => `@${e.case.displayId}`);
			selectedRun = { id: run.id, title: run.title, tags };
		} catch {
			selectedRun = null;
		} finally {
			selectedRunLoading = false;
		}
	}

	function clearSelectedRun() {
		selectedRun = null;
	}

	function handleRunClick() {
		const notify = { notifyDiscord, notifySlack };
		if (selectedRun) {
			if (selectedRunLoading || !selectedRun.tags) return;
			if (selectedRun.tags.length === 0) return;
			triggerRun(selectedRun.tags.join(' or '), selectedRun.id, notify, selectedRun.title);
		} else if ($runnerConfig.testID.trim() === '') {
			runAllModalOpen = true;
		} else {
			triggerRun(undefined, undefined, notify);
		}
	}

	function handleKeydown(e) {
		if (e.key === 'Enter' && !selectedRun) handleRunClick();
	}

	function adjustWorkers(delta) {
		runnerConfig.update((c) => ({
			...c,
			workers: Math.max(WORKERS_MIN, Math.min(WORKERS_MAX, c.workers + delta))
		}));
	}

	function toggleRunner(id) {
		runnerConfig.update((c) => {
			const set = new Set(c.selectedRunners);
			if (set.has(id)) {
				set.delete(id);
				// Never leave the selection empty, fall back to the built-in runner
				// when it's available, otherwise keep this one selected.
				if (set.size === 0) {
					if ($builtInEnabled) set.add(BUILTIN_RUNNER_ID);
					else return c;
				}
			} else {
				set.add(id);
			}
			return { ...c, selectedRunners: [...set] };
		});
	}

	function isRunnerSelected(id) {
		return $runnerConfig.selectedRunners.includes(id);
	}

	// A checkbox's `checked={isRunnerSelected(id)}` isn't reactive, Svelte can't
	// see the `$runnerConfig` read hidden in the call. Bind to this set instead so
	// the picker always mirrors the model, including a sibling flipped by a toggle.
	$: selectedRunnerSet = new Set($runnerConfig.selectedRunners);

	async function pingNodes() {
		if (availableRunners.length === 0) return;
		nodePings = Object.fromEntries(availableRunners.map((r) => [r.id, 'checking']));
		await Promise.all(
			availableRunners.map(async (r) => {
				let ok = false;
				try {
					ok = (await pingRunner(r.id))?.ok === true;
				} catch {
					ok = false;
				}
				nodePings = { ...nodePings, [r.id]: ok ? 'up' : 'down' };
			})
		);
	}
</script>

<!-- Run all disclaimer -->
<ConfirmModal
	bind:open={runAllModalOpen}
	title={RUN_ALL_TITLE}
	confirmLabel={RUN_ALL_CONFIRM_LABEL}
	on:confirm={() => {
		runAllModalOpen = false;
		triggerRun(undefined, undefined, { notifyDiscord, notifySlack });
	}}
>
	{RUN_ALL_BODY_PREFIX} <strong>{RUN_ALL_BODY_STRONG}</strong>
	{RUN_ALL_BODY_SUFFIX}
</ConfirmModal>

<div class="panel" class:expanded={$panelExpanded}>
	<div
		class="scan-line"
		class:scanning={runningCount > 0}
		class:line-pass={lastFinished?.verdict === 'pass' && !anyRunning}
		class:line-fail={lastFinished?.verdict === 'fail' && !anyRunning}
	></div>

	<!-- ── Control bar ── -->
	<div class="bar">
		<!-- Left: status + view report -->
		<div class="bar-left">
			<div class="bar-status">
				<span class="status-dot" class:pulse={runningCount > 0} style="background:{statusColor}"
				></span>
				<span class="status-word" style="color:{statusColor}">{statusLabel}</span>
			</div>
			{#if !anyRunning && lastFinished?.reportId}
				<a
					href={reportUrl(lastFinished.reportId)}
					class="view-report-btn"
					on:click={() => panelExpanded.set(false)}
					transition:fly={{ x: -6, duration: 200 }}
				>
					{VIEW_REPORT_LABEL}
					<svg
						width="11"
						height="11"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						stroke-width="2"
						stroke-linecap="round"
						stroke-linejoin="round"
					>
						<line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
					</svg>
				</a>
			{/if}
		</div>

		<span class="flex-gap"></span>

		<!-- Middle: tag filter + browser + workers + runner dropdowns -->
		<div class="bar-center">
			<!-- Test Run picker OR tag input -->
			{#if selectedRun}
				<div class="run-chip" class:loading={selectedRunLoading}>
					<svg
						width="9"
						height="10"
						viewBox="0 0 10 12"
						fill="currentColor"
						stroke="none"
						style="opacity:0.6;flex-shrink:0"><polygon points="0,0 10,6 0,12" /></svg
					>
					<span class="run-chip-title">{selectedRun.title}</span>
					{#if selectedRunLoading}
						<span class="run-chip-spinner"></span>
					{:else if selectedRun.tags !== null}
						<span class="run-chip-count" class:none={selectedRun.tags.length === 0}>
							{automatedCaseCount(selectedRun.tags.length)}
						</span>
					{/if}
					<button
						class="run-chip-clear"
						on:click={clearSelectedRun}
						aria-label={CLEAR_TEST_RUN_LABEL}
					>
						<svg width="9" height="9" viewBox="0 0 14 14" fill="none"
							><path
								d="M1 1l12 12M13 1L1 13"
								stroke="currentColor"
								stroke-width="1.5"
								stroke-linecap="round"
							/></svg
						>
					</button>
				</div>
			{:else}
				<div class="input-wrap">
					<svg
						class="input-icon"
						width="12"
						height="12"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						stroke-width="2"
						stroke-linecap="round"
						stroke-linejoin="round"
					>
						<circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
					</svg>
					<input
						type="text"
						class="tag-input"
						value={$runnerConfig.testID}
						placeholder="@tag or leave blank for all tests"
						on:input={(e) => runnerConfig.update((c) => ({ ...c, testID: e.currentTarget.value }))}
						on:keydown={handleKeydown}
					/>
				</div>
			{/if}

			<!-- Test run dropdown -->
			<div class="ctrl-group">
				<span class="ctrl-label">{TEST_RUN_LABEL}</span>
				<div class="dropdown-wrap" use:clickOutside on:clickoutside={() => (runPickOpen = false)}>
					<button
						class="dropdown-trigger"
						class:open={runPickOpen}
						class:has-remote={!!selectedRun}
						on:click={() => {
							runPickOpen = !runPickOpen;
						}}
					>
						<span>{selectedRun ? selectedRun.title : NO_RUN_SELECTED_LABEL}</span>
						<svg
							width="10"
							height="10"
							viewBox="0 0 24 24"
							fill="none"
							stroke="currentColor"
							stroke-width="2.5"
							stroke-linecap="round"
							class="trigger-chevron"
							class:open={runPickOpen}
						>
							<polyline points="6 9 12 15 18 9" />
						</svg>
					</button>
					{#if runPickOpen}
						<div class="dropdown-menu run-pick-menu" transition:fly={{ y: 6, duration: 130 }}>
							{#if selectedRun}
								<button class="dropdown-item" on:click={clearSelectedRun}>
									<span style="color:var(--text-muted)">✕</span>
									{CLEAR_LABEL}
								</button>
								<div class="dropdown-divider"></div>
							{/if}
							{#if testRuns.filter((r) => r.status !== 'complete').length === 0}
								<div class="dropdown-empty">{NO_ACTIVE_TEST_RUNS}</div>
							{:else}
								{#each testRuns.filter((r) => r.status !== 'complete') as run}
									<button
										class="dropdown-item"
										class:active={selectedRun?.id === run.id}
										on:click={() => selectRun(run)}
									>
										{run.title}
									</button>
								{/each}
							{/if}
						</div>
					{/if}
				</div>
			</div>

			<div class="ctrl-divider"></div>

			<!-- Workers stepper -->
			<div class="ctrl-group">
				<span class="ctrl-label">{WORKERS_LABEL}</span>
				<div class="stepper">
					<button
						class="step-btn"
						on:click={() => adjustWorkers(-1)}
						disabled={cfg.workers <= WORKERS_MIN}>−</button
					>
					<span class="step-val">{cfg.workers}</span>
					<button
						class="step-btn"
						on:click={() => adjustWorkers(1)}
						disabled={cfg.workers >= WORKERS_MAX}>+</button
					>
				</div>
			</div>

			<div class="ctrl-divider"></div>

			<!-- Browser -->
			<div class="ctrl-group">
				<span class="ctrl-label">{BROWSER_LABEL}</span>
				<IconSelect
					variant="bar"
					placement="top"
					animate
					options={BROWSERS}
					value={cfg.browser}
					on:change={(e) => runnerConfig.update((c) => ({ ...c, browser: e.detail }))}
				/>
			</div>

			<!-- Runners (only when external runners exist) -->
			{#if availableRunners.length > 0}
				<div class="ctrl-divider"></div>
				<div class="ctrl-group">
					<span class="ctrl-label">{RUNNERS_LABEL}</span>
					<div class="dropdown-wrap" use:clickOutside on:clickoutside={() => (runnersOpen = false)}>
						<button
							class="dropdown-trigger"
							class:open={runnersOpen}
							class:has-remote={cfg.selectedRunners.some((r) => r !== BUILTIN_RUNNER_ID)}
							on:click={() => {
								runnersOpen = !runnersOpen;
								if (runnersOpen) pingNodes();
							}}
						>
							<span>{runnerSummary}</span>
							<svg
								width="10"
								height="10"
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="2.5"
								stroke-linecap="round"
								class="trigger-chevron"
								class:open={runnersOpen}
							>
								<polyline points="6 9 12 15 18 9" />
							</svg>
						</button>
						{#if runnersOpen}
							<div class="dropdown-menu runners-menu" transition:fly={{ y: 6, duration: 130 }}>
								{#if $builtInEnabled || selectedRunnerSet.has(BUILTIN_RUNNER_ID)}
									<label class="runner-option">
										<input
											type="checkbox"
											checked={selectedRunnerSet.has(BUILTIN_RUNNER_ID)}
											on:change={() => toggleRunner(BUILTIN_RUNNER_ID)}
										/>
										<span class="runner-dot built-in"></span>
										<span>{BUILTIN_RUNNER_LABEL}</span>
									</label>
								{/if}
								{#each availableRunners as r}
									{@const state = nodePings[r.id]}
									{@const selected = selectedRunnerSet.has(r.id)}
									<label class="runner-option" class:offline={state === 'down'}>
										<input
											type="checkbox"
											checked={selected}
											disabled={state === 'down' && !selected}
											on:change={() => toggleRunner(r.id)}
										/>
										<span
											class="runner-dot remote"
											class:up={state === 'up'}
											class:down={state === 'down'}
											class:checking={state === 'checking'}
										></span>
										<span>{r.name}</span>
										{#if state === 'down'}<span class="runner-offline-tag">{OFFLINE_LABEL}</span
											>{/if}
									</label>
								{/each}
							</div>
						{/if}
					</div>
				</div>
			{/if}

			{#if integrations.discordWebhookUrl || integrations.slackWebhookUrl}
				<div class="ctrl-divider"></div>
				<div class="ctrl-group">
					<span class="ctrl-label">{NOTIFY_LABEL}</span>
					<div class="notify-toggles">
						{#if integrations.discordWebhookUrl}
							<button
								type="button"
								class="notify-btn"
								class:active={notifyDiscord}
								on:click={() => (notifyDiscord = !notifyDiscord)}
								title={discordNotifyTitle(notifyDiscord)}
							>
								<ServiceIcon service="discord" size={13} />
								{DISCORD_LABEL}
							</button>
						{/if}
						{#if integrations.slackWebhookUrl}
							<button
								type="button"
								class="notify-btn"
								class:active={notifySlack}
								on:click={() => (notifySlack = !notifySlack)}
								title={slackNotifyTitle(notifySlack)}
							>
								<ServiceIcon service="slack" size={13} />
								{SLACK_LABEL}
							</button>
						{/if}
					</div>
				</div>
			{/if}

			<div class="ctrl-divider"></div>

			<!-- Run button, a run while one is active just queues another -->
			<button
				class="run-btn"
				on:click={handleRunClick}
				disabled={selectedRunLoading || (selectedRun && selectedRun.tags?.length === 0)}
				title={selectedRun && selectedRun.tags?.length === 0 ? NO_AUTOMATED_CASES_TITLE : undefined}
			>
				<svg width="9" height="10" viewBox="0 0 10 12" fill="currentColor" stroke="none">
					<polygon points="0,0 10,6 0,12" />
				</svg>
				{RUN_LABEL}
			</button>
		</div>

		<span class="flex-gap-sm"></span>

		<!-- Right: expand toggle -->
		<button
			class="expand-btn"
			on:click={() => panelExpanded.update((v) => !v)}
			aria-label={collapseOrExpandLabel($panelExpanded)}
		>
			<svg
				width="14"
				height="14"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
				class:flipped={$panelExpanded}
			>
				<polyline points="18 15 12 9 6 15" />
			</svg>
		</button>
	</div>

	<!-- ── Expanded: active runs only ── -->
	{#if $panelExpanded}
		<div class="body" transition:slide={{ duration: 200 }}>
			{#each activeRunEntries as [runId, run], i (runId)}
				{@const openable = canOpenRun(run)}
				<div
					class="run-card"
					class:active-run={run.status === 'running'}
					class:queued-run={run.status === 'queued'}
					transition:fly={{ x: -4, duration: 160 }}
				>
					<span
						class="run-card-dot"
						class:pulse-accent={run.status === 'running'}
						class:queued-dot={run.status === 'queued'}
					></span>
					<!-- svelte-ignore a11y_no_static_element_interactions -->
					<svelte:element
						this={openable ? 'a' : 'div'}
						href={openable ? `/live/${runId}` : undefined}
						role={openable ? undefined : 'presentation'}
						class="run-card-main"
						class:locked={!openable}
						title={openable ? undefined : lockedRunTitle(run.projectName)}
						on:click={openable ? () => panelExpanded.set(false) : undefined}
					>
						<div class="run-card-info">
							<span class="run-card-label">{run.label || MANUAL_RUN_LABEL}</span>
							<span class="run-card-meta">
								{#if !openable}
									<!-- A locked row is otherwise indistinguishable from a clickable
									     one, so clicking it looked like nothing happened. -->
									<span class="run-card-lock"><LockIcon size={11} strokeWidth={2.5} /></span>
								{/if}
								{#if run.projectName}
									<span class="run-card-project">{run.projectName}</span>
									<span class="meta-dot">·</span>
								{/if}
								{run.status === 'queued'
									? queuePositionLabel(
											activeRunEntries.slice(0, i).filter(([, r]) => r.status === 'queued').length +
												1
										)
									: runKindLabel(run.kind)}
								{#if run.currentRun?.startedBy}
									<span class="meta-dot">·</span>
									{startedByLabel(
										mcpName(run.currentRun.startedBy, run.kind === TRIGGER_TYPES.MCP)
									)}
								{/if}
							</span>
						</div>
						<Badge variant={run.status === 'queued' ? 'tag' : triggerVariant(run.kind)}>
							{run.status === 'queued' ? QUEUED_LABEL : triggerLabel(run.kind)}
						</Badge>
						{#if openable}
							<svg
								width="13"
								height="13"
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="2"
								stroke-linecap="round"
								class="run-card-arrow"
							>
								<line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
							</svg>
						{/if}
					</svelte:element>
					{#if openable}
						<button
							class="run-card-cancel"
							title={CANCEL_RUN_LABEL}
							aria-label={CANCEL_RUN_LABEL}
							on:click={() => cancelRun(runId)}
						>
							<svg width="12" height="12" viewBox="0 0 14 14" fill="none">
								<path
									d="M1 1l12 12M13 1L1 13"
									stroke="currentColor"
									stroke-width="1.6"
									stroke-linecap="round"
								/>
							</svg>
						</button>
					{/if}
				</div>
			{/each}

			{#if !anyRunning}
				<div class="empty-runs">
					<svg
						width="18"
						height="18"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						stroke-width="1.5"
						stroke-linecap="round"
						stroke-linejoin="round"
						class="empty-icon"
					>
						<circle cx="12" cy="12" r="10" />
						<line x1="12" y1="16" x2="12" y2="12" />
						<line x1="12" y1="8" x2="12.01" y2="8" />
					</svg>
					{NO_TESTS_RUNNING}
				</div>
			{/if}
		</div>
	{/if}
</div>

<style>
	/* ── Panel shell ── */
	.panel {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		z-index: 200;
		background: var(--bg-elevated);
		border-top: 1px solid var(--border);
		box-shadow: 0 -4px 32px rgba(0, 0, 0, 0.07);
	}

	/* ── Scan-line ── */
	.scan-line {
		height: 2px;
		background: var(--border);
		transition: background 0.5s ease;
		overflow: hidden;
		position: relative;
	}

	.scan-line.scanning {
		background: color-mix(in srgb, var(--accent) 30%, var(--border));
	}

	.scan-line.scanning::after {
		content: '';
		position: absolute;
		inset: 0;
		width: 35%;
		background: linear-gradient(90deg, transparent, var(--accent), transparent);
		animation: scan 1.8s ease-in-out infinite;
	}

	.scan-line.line-pass {
		background: var(--pass);
	}
	.scan-line.line-fail {
		background: var(--fail);
	}

	@keyframes scan {
		0% {
			transform: translateX(-100%);
		}
		100% {
			transform: translateX(400%);
		}
	}

	/* ── Bar ── */
	.bar {
		display: flex;
		align-items: center;
		height: 52px;
		padding: 0 1rem 0 1.25rem;
		gap: 0.75rem;
	}

	.flex-gap {
		flex: 1;
	}
	.flex-gap-sm {
		width: 0.5rem;
	}

	/* ── Left: status ── */
	.bar-left {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		flex-shrink: 0;
	}

	.bar-status {
		display: flex;
		align-items: center;
		gap: 0.5rem;
	}

	.status-dot {
		width: 7px;
		height: 7px;
		border-radius: 50%;
		flex-shrink: 0;
		transition: background 0.4s ease;
	}

	.status-dot.pulse {
		animation: dotPulse 1.6s ease-in-out infinite;
	}

	.status-word {
		font-size: 0.72rem;
		font-weight: 600;
		letter-spacing: 0.05em;
		text-transform: uppercase;
		transition: color 0.4s ease;
		white-space: nowrap;
	}

	.view-report-btn {
		display: inline-flex;
		align-items: center;
		gap: 0.3rem;
		font-size: 0.75rem;
		font-weight: 500;
		color: var(--accent);
		text-decoration: none;
		white-space: nowrap;
		border: 1px solid var(--accent);
		border-radius: var(--radius-sm);
		padding: 0.2rem 0.6rem;
		background: var(--accent-soft);
		transition:
			background var(--duration-fast),
			color var(--duration-fast);
	}

	.view-report-btn:hover {
		background: var(--accent);
		color: var(--white);
	}

	/* ── Center: controls ── */
	.bar-center {
		display: flex;
		align-items: center;
		gap: 0.625rem;
	}

	/* Tag input */
	.input-wrap {
		position: relative;
		display: flex;
		align-items: center;
	}

	.input-icon {
		position: absolute;
		left: 0.6rem;
		color: var(--text-muted);
		pointer-events: none;
		opacity: 0.6;
	}

	.tag-input {
		height: 28px;
		padding: 0 0.75rem 0 2rem;
		font-size: 0.8rem;
		font-family: 'JetBrains Mono', monospace;
		background: var(--bg-subtle);
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		color: var(--text);
		outline: none;
		transition: border-color var(--duration-fast);
		width: 200px;
	}

	.tag-input:focus {
		border-color: var(--accent);
	}
	.tag-input::placeholder {
		color: var(--text-muted);
		opacity: 0.45;
	}
	.tag-input:disabled {
		opacity: 0.45;
	}

	.ctrl-divider {
		width: 1px;
		height: 24px;
		background: var(--border);
		flex-shrink: 0;
	}

	/* Workers stepper */
	.ctrl-group {
		display: flex;
		flex-direction: column;
		gap: 2px;
	}

	.ctrl-label {
		font-size: 0.555rem;
		font-weight: 600;
		letter-spacing: 0.09em;
		text-transform: uppercase;
		color: var(--text-muted);
		opacity: 0.65;
		line-height: 1;
	}

	.stepper {
		display: flex;
		align-items: center;
		background: var(--bg-subtle);
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		overflow: hidden;
	}

	.step-btn {
		width: 20px;
		height: 24px;
		display: flex;
		align-items: center;
		justify-content: center;
		border: none;
		background: transparent;
		color: var(--text-muted);
		cursor: pointer;
		font-size: 0.875rem;
		font-weight: 400;
		line-height: 1;
		transition:
			color var(--duration-fast),
			background var(--duration-fast);
	}

	.step-btn:hover:not(:disabled) {
		color: var(--text);
		background: var(--bg-elevated);
	}
	.step-btn:disabled {
		opacity: 0.3;
		cursor: default;
	}

	.step-val {
		min-width: 20px;
		text-align: center;
		font-size: 0.78rem;
		font-weight: 500;
		color: var(--text);
		font-family: 'JetBrains Mono', monospace;
		line-height: 24px;
		border-left: 1px solid var(--border);
		border-right: 1px solid var(--border);
	}

	/* Dropdown */
	.dropdown-wrap {
		position: relative;
	}

	.dropdown-trigger {
		display: inline-flex;
		align-items: center;
		gap: 0.3rem;
		height: 24px;
		padding: 0 0.5rem;
		background: var(--bg-subtle);
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		font-family: var(--font-body);
		font-size: 0.78rem;
		color: var(--text);
		cursor: pointer;
		transition:
			border-color var(--duration-fast),
			background var(--duration-fast),
			color var(--duration-fast);
		white-space: nowrap;
	}

	.dropdown-trigger:hover:not(:disabled) {
		border-color: color-mix(in srgb, var(--text-muted) 50%, var(--border));
	}
	.dropdown-trigger.open {
		border-color: var(--accent);
		background: var(--accent-soft);
		color: var(--accent);
	}
	.dropdown-trigger.has-remote {
		border-color: var(--accent);
		color: var(--accent);
		background: var(--accent-soft);
	}
	.dropdown-trigger:disabled {
		opacity: 0.45;
		cursor: default;
	}

	.trigger-chevron {
		transition: transform 0.18s var(--ease-out);
		flex-shrink: 0;
	}
	.trigger-chevron.open {
		transform: rotate(180deg);
	}

	.dropdown-menu {
		position: absolute;
		bottom: calc(100% + 8px);
		left: 0;
		min-width: 130px;
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-md);
		box-shadow: 0 8px 28px rgba(0, 0, 0, 0.13);
		padding: 0.3rem;
		z-index: 300;
		display: flex;
		flex-direction: column;
		gap: 1px;
	}

	.dropdown-item {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		width: 100%;
		padding: 0.35rem 0.5rem;
		border: none;
		border-radius: var(--radius-sm);
		background: transparent;
		font-family: var(--font-body);
		font-size: 0.8125rem;
		color: var(--text);
		cursor: pointer;
		text-align: left;
		transition: background var(--duration-fast);
	}

	.dropdown-item:hover {
		background: var(--bg-subtle);
	}
	.dropdown-item.active {
		color: var(--accent);
	}

	.runners-menu {
		min-width: 160px;
	}

	.runner-option {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		padding: 0.35rem 0.5rem;
		border-radius: var(--radius-sm);
		cursor: pointer;
		font-size: 0.8125rem;
		color: var(--text);
		transition: background var(--duration-fast);
	}

	.runner-option:hover {
		background: var(--bg-subtle);
	}
	.runner-option:has(input:disabled) {
		cursor: not-allowed;
	}
	.runner-option input[type='checkbox'] {
		accent-color: var(--accent);
		width: 13px;
		height: 13px;
		cursor: pointer;
		flex-shrink: 0;
	}
	.runner-option input[type='checkbox']:disabled {
		cursor: not-allowed;
	}
	.runner-dot {
		width: 6px;
		height: 6px;
		border-radius: 50%;
		flex-shrink: 0;
	}
	.runner-dot.built-in {
		background: var(--accent);
	}
	/* Remote node health, grey until a ping lands, then pass/fail. */
	.runner-dot.remote {
		background: var(--border);
	}
	.runner-dot.remote.up {
		background: var(--pass);
	}
	.runner-dot.remote.down {
		background: var(--fail);
	}
	.runner-dot.remote.checking {
		background: var(--text-muted);
		animation: dotPulse 1.2s ease-in-out infinite;
	}

	.runner-option.offline {
		opacity: 0.6;
	}
	.runner-offline-tag {
		margin-left: auto;
		font-size: 0.68rem;
		text-transform: uppercase;
		letter-spacing: 0.04em;
		color: var(--fail);
	}

	/* Run button */
	.run-btn {
		display: inline-flex;
		align-items: center;
		gap: 0.4rem;
		height: 30px;
		padding: 0 0.875rem;
		background: var(--accent);
		color: var(--white);
		border: none;
		border-radius: var(--radius-sm);
		font-family: var(--font-body);
		font-size: 0.8125rem;
		font-weight: 500;
		cursor: pointer;
		transition: opacity var(--duration-fast);
		flex-shrink: 0;
	}

	.run-btn:hover:not(:disabled) {
		opacity: 0.88;
	}
	.run-btn:disabled {
		opacity: 0.6;
		cursor: default;
	}

	@keyframes spin {
		to {
			transform: rotate(360deg);
		}
	}

	/* Notification toggles */
	.notify-toggles {
		display: flex;
		gap: 0.25rem;
	}

	.notify-btn {
		display: inline-flex;
		align-items: center;
		gap: 0.35rem;
		height: 26px;
		padding: 0 0.5rem;
		border-radius: var(--radius-sm);
		border: 1px solid var(--border);
		background: transparent;
		color: var(--text-muted);
		font-size: 0.75rem;
		font-family: inherit;
		cursor: pointer;
		transition:
			background var(--duration-fast),
			color var(--duration-fast),
			border-color var(--duration-fast);
	}

	.notify-btn:hover:not(:disabled) {
		color: var(--text);
		border-color: var(--text-muted);
	}

	.notify-btn.active {
		background: var(--accent);
		border-color: var(--accent);
		color: var(--white);
	}

	.notify-btn:disabled {
		opacity: 0.4;
		cursor: default;
	}

	/* Expand button */
	.expand-btn {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 28px;
		height: 28px;
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		background: transparent;
		color: var(--text-muted);
		cursor: pointer;
		transition:
			background var(--duration-fast),
			color var(--duration-fast),
			border-color var(--duration-fast);
		flex-shrink: 0;
	}

	.expand-btn:hover {
		background: var(--bg-subtle);
		color: var(--text);
		border-color: var(--text-muted);
	}
	.expand-btn svg {
		transition: transform 0.2s var(--ease-out);
	}
	.expand-btn svg.flipped {
		transform: rotate(180deg);
	}

	/* ── Expanded body ── */
	.body {
		border-top: 1px solid var(--border);
		padding: 0.625rem 1.25rem;
		display: flex;
		flex-direction: column;
		gap: 0.375rem;
		min-height: 72px;
	}

	/* Active run card */
	.run-card {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		padding: 0.625rem 0.875rem;
		border: 1px solid var(--border);
		border-radius: var(--radius-md);
		background: var(--bg-subtle);
		color: inherit;
		transition:
			background var(--duration-fast),
			border-color var(--duration-fast);
	}

	.run-card:hover {
		background: var(--bg-elevated);
		border-color: var(--accent);
	}

	.run-card.active-run {
		border-left: 3px solid var(--accent);
	}
	.run-card.queued-run {
		border-left: 3px solid var(--warn);
	}

	.run-card-main {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		flex: 1;
		min-width: 0;
		text-decoration: none;
		color: inherit;
	}
	.run-card-main.locked {
		cursor: not-allowed;
	}
	.run-card-main.locked .run-card-label {
		color: var(--text-muted);
	}
	.run-card-lock {
		color: var(--warn);
		flex-shrink: 0;
		vertical-align: -1px;
	}

	.run-card-project {
		font-weight: 600;
		color: var(--text);
	}

	.run-card-cancel {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 22px;
		height: 22px;
		flex-shrink: 0;
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		background: transparent;
		color: var(--text-muted);
		cursor: pointer;
		transition:
			color var(--duration-fast),
			border-color var(--duration-fast);
	}
	.run-card-cancel:hover {
		color: var(--fail);
		border-color: var(--fail);
	}

	.run-card-dot {
		width: 8px;
		height: 8px;
		border-radius: 50%;
		flex-shrink: 0;
		background: var(--border);
	}

	.pulse-accent {
		background: var(--accent);
		animation: dotPulse 1.6s ease-in-out infinite;
	}

	.queued-dot {
		background: var(--warn);
	}

	.run-card-info {
		display: flex;
		flex-direction: column;
		gap: 0.1rem;
		flex: 1;
		min-width: 0;
	}

	.run-card-label {
		font-size: 0.8125rem;
		font-weight: 500;
		color: var(--text);
	}

	.run-card-meta {
		font-size: 0.72rem;
		font-family: 'JetBrains Mono', monospace;
		color: var(--text-muted);
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.meta-dot {
		opacity: 0.4;
		margin: 0 0.15rem;
	}

	.run-card-arrow {
		color: var(--text-muted);
		flex-shrink: 0;
		transition:
			transform var(--duration-fast) var(--ease-out),
			color var(--duration-fast);
	}

	.run-card:hover .run-card-arrow {
		transform: translateX(3px);
		color: var(--accent);
	}

	/* Empty state */
	.empty-runs {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 0.5rem;
		padding: 0.5rem 0;
		color: var(--text-muted);
		font-size: 0.8125rem;
	}

	.empty-icon {
		opacity: 0.4;
	}

	/* ── Run chip (selected test run display) ── */
	.run-chip {
		display: inline-flex;
		align-items: center;
		gap: 0.4rem;
		height: 28px;
		padding: 0 0.5rem 0 0.625rem;
		background: var(--accent-soft);
		border: 1px solid var(--accent);
		border-radius: var(--radius-sm);
		color: var(--accent);
		font-size: 0.78rem;
		white-space: nowrap;
		max-width: 200px;
	}

	.run-chip-title {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		flex: 1;
		min-width: 0;
	}

	.run-chip-count {
		font-size: 0.65rem;
		font-weight: 600;
		letter-spacing: 0.04em;
		opacity: 0.75;
		white-space: nowrap;
		flex-shrink: 0;
	}

	.run-chip-count.none {
		color: var(--fail);
		opacity: 1;
	}

	.run-chip-spinner {
		width: 9px;
		height: 9px;
		border: 1.5px solid color-mix(in srgb, var(--accent) 35%, transparent);
		border-top-color: var(--accent);
		border-radius: 50%;
		animation: spin 0.65s linear infinite;
		flex-shrink: 0;
	}

	.run-chip-clear {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 16px;
		height: 16px;
		border: none;
		background: transparent;
		color: var(--accent);
		cursor: pointer;
		border-radius: 2px;
		opacity: 0.7;
		padding: 0;
		flex-shrink: 0;
		transition: opacity var(--duration-fast);
	}

	.run-chip-clear:hover {
		opacity: 1;
	}

	.run-pick-menu {
		min-width: 180px;
		max-height: 240px;
		overflow-y: auto;
	}

	.dropdown-divider {
		height: 1px;
		background: var(--border);
		margin: 0.25rem 0;
	}

	.dropdown-empty {
		font-size: 0.8125rem;
		color: var(--text-muted);
		padding: 0.35rem 0.5rem;
		text-align: center;
		opacity: 0.7;
	}

	/* Mobile: the control row reuses the drawer, hidden until the bar is expanded. */
	@media (max-width: 640px) {
		.bar {
			flex-wrap: wrap;
			height: auto;
			min-height: 52px;
			padding: 0.5rem 0.875rem;
			gap: 0.5rem;
		}

		.flex-gap,
		.flex-gap-sm {
			display: none;
		}

		.bar-left {
			flex: 1;
			min-width: 0;
		}

		.run-btn {
			order: 2;
			height: 32px;
		}

		.expand-btn {
			order: 3;
		}

		.bar-center {
			order: 10;
			flex-basis: 100%;
			flex-wrap: wrap;
			gap: 0.5rem 0.625rem;
			padding-top: 0.625rem;
			border-top: 1px solid var(--border);
		}

		.panel:not(.expanded) .bar-center {
			display: none;
		}

		.ctrl-divider {
			display: none;
		}

		.input-wrap,
		.run-chip {
			flex-basis: 100%;
			max-width: none;
		}

		.tag-input {
			width: 100%;
		}

		.bar-center > .ctrl-group {
			flex: 1 1 calc(50% - 0.32rem);
			min-width: 0;
		}

		/* Content-width, else the half-width column balloons the +/− hit areas. */
		.bar-center > .ctrl-group:has(.stepper) {
			flex: 0 0 auto;
		}

		.stepper {
			align-self: flex-start;
		}

		.dropdown-wrap {
			width: 100%;
		}

		.dropdown-trigger {
			width: 100%;
			justify-content: space-between;
		}

		.dropdown-menu {
			max-width: calc(100vw - 1.75rem);
		}

		.notify-toggles {
			flex-wrap: wrap;
		}

		.body {
			padding: 0.625rem 0.875rem;
		}

		.run-card {
			flex-wrap: wrap;
		}
	}
</style>
