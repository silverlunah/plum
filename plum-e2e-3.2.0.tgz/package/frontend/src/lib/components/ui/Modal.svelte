<!--
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 -->

<script>
	import { fade, scale } from 'svelte/transition';
	import { cubicOut } from 'svelte/easing';

	export let open = false;
	export let title = '';

	let mousedownOnBackdrop = false;

	function close() {
		open = false;
	}

	function onBackdropMousedown(e) {
		mousedownOnBackdrop = e.target === e.currentTarget;
	}

	function onBackdrop(e) {
		if (e.target === e.currentTarget && mousedownOnBackdrop) close();
	}

	function onKeydown(e) {
		if (e.key === 'Escape') close();
	}
</script>

<svelte:window on:keydown={onKeydown} />

{#if open}
	<div
		class="backdrop"
		role="presentation"
		on:mousedown={onBackdropMousedown}
		on:click={onBackdrop}
		on:keydown={(e) => e.key === 'Escape' && close()}
		transition:fade={{ duration: 200 }}
	>
		<div
			class="panel"
			role="dialog"
			aria-modal="true"
			aria-label={title}
			transition:scale={{ start: 0.96, duration: 260, easing: cubicOut }}
		>
			<div class="header">
				<h3 class="title">{title}</h3>
				<button class="close-btn" on:click={close} aria-label="Close">
					<svg width="14" height="14" viewBox="0 0 14 14" fill="none">
						<path
							d="M1 1l12 12M13 1L1 13"
							stroke="currentColor"
							stroke-width="1.5"
							stroke-linecap="round"
						/>
					</svg>
				</button>
			</div>
			<div class="body">
				<slot />
			</div>
		</div>
	</div>
{/if}

<style>
	.backdrop {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: var(--bottom-bar-height);
		background: rgba(0, 0, 0, 0.45);
		display: flex;
		align-items: center;
		justify-content: center;
		z-index: 50;
		padding: 1rem;
		backdrop-filter: blur(2px);
		overflow-y: auto;
	}

	.panel {
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-lg);
		padding: 1.75rem;
		width: 100%;
		max-width: 480px;
		max-height: 100%;
		overflow-y: auto;
		box-shadow:
			0 4px 6px rgba(0, 0, 0, 0.04),
			0 24px 64px rgba(0, 0, 0, 0.14);
	}

	.header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 1.5rem;
	}

	.title {
		font-family: var(--font-display);
		font-size: 1.2rem;
		font-weight: 400;
		color: var(--text);
	}

	.close-btn {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 28px;
		height: 28px;
		border-radius: var(--radius-sm);
		border: none;
		background: transparent;
		color: var(--text-muted);
		cursor: pointer;
		transition:
			background var(--duration-fast),
			color var(--duration-fast);
	}

	.close-btn:hover {
		background: var(--bg-subtle);
		color: var(--text);
	}

	.body {
		display: flex;
		flex-direction: column;
		gap: 1rem;
	}

	@media (max-width: 640px) {
		.backdrop {
			align-items: flex-end;
			padding: 0;
		}

		.panel {
			max-width: none;
			max-height: 88vh;
			border-radius: var(--radius-lg) var(--radius-lg) 0 0;
			padding: 1.25rem 1.25rem calc(1.25rem + env(safe-area-inset-bottom, 0px));
		}

		.header {
			margin-bottom: 1rem;
		}
	}
</style>
