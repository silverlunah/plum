<!--
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 -->

<script>
	import { onDestroy } from 'svelte';
	import { browser } from '$app/environment';
	import { slide } from 'svelte/transition';
	import { fetchSuites } from '$lib/api/tests';
	import { runnerConfig, triggerRun } from '$lib/stores/runner';
	import { activeProjectId } from '$lib/stores/project';
	import { COPY_TIMEOUT_MS } from '$lib/constants';
	import { stagger } from '$lib/utils/format';
	import { copyText } from '$lib/utils/clipboard';
	import EmptyState from '$lib/components/ui/EmptyState.svelte';
	import LearnMoreLinks from '$lib/components/ui/LearnMoreLinks.svelte';
	import { CLEAR_SEARCH_LABEL, SORT_BY_LABEL } from '$lib/copy/common';
	import {
		PAGE_TITLE,
		HEADING,
		SEARCH_PLACEHOLDER,
		NO_SUITES_MESSAGE,
		REPO_MANAGED_NOTE,
		RUN_SUITE_LABEL,
		OUTLINE_BADGE,
		HIDE_LABEL,
		STEPS_LABEL,
		EXAMPLES_LABEL,
		noMatchMessage,
		copiedTitle,
		copyTitle,
		runIdTitle,
		runTestLabel,
		visibleOfTotal,
		testCountLabel,
		suiteSummary,
		collapseOrExpandSuiteLabel
	} from '$lib/copy/dashboard';

	let suites = [];
	let search = '';
	let expandedSteps = new Set();
	// Suites are expanded by default, this tracks the exceptions (collapsed ones).
	let collapsedSuites = new Set();
	let copiedIds = new Set();
	const copyTimers = new Map();

	function readSort(key, fallback) {
		try {
			const v = sessionStorage.getItem(key);
			if (v) return JSON.parse(v);
		} catch {}
		return fallback;
	}

	function writeSort(key, value) {
		try {
			sessionStorage.setItem(key, JSON.stringify(value));
		} catch {}
	}

	let sort = readSort('plum:automated-tests:sort', { by: 'id', order: 'desc' });

	function applySort(by) {
		sort =
			sort.by === by
				? { ...sort, order: sort.order === 'asc' ? 'desc' : 'asc' }
				: { by, order: by === 'id' ? 'desc' : 'asc' };
		writeSort('plum:automated-tests:sort', sort);
	}

	async function loadSuites() {
		try {
			suites = await fetchSuites();
		} catch (e) {
			console.error('Failed to fetch suites', e);
		}
	}

	// Reactive, not onMount: after login the switcher sets the active project
	// just after this mounts, and a fetch on the stale id would 403.
	$: if (browser) {
		$activeProjectId;
		loadSuites();
	}

	function suiteIds(suite) {
		return Array.isArray(suite.suiteId) ? suite.suiteId : [suite.suiteId];
	}

	function testIds(test) {
		return Array.isArray(test.id) ? test.id : [test.id];
	}

	function primaryId(test) {
		return Array.isArray(test.id) ? test.id[0] : test.id;
	}

	function toggleSteps(id) {
		if (expandedSteps.has(id)) expandedSteps.delete(id);
		else expandedSteps.add(id);
		expandedSteps = expandedSteps;
	}

	function toggleSuite(id) {
		if (collapsedSuites.has(id)) collapsedSuites.delete(id);
		else collapsedSuites.add(id);
		collapsedSuites = collapsedSuites;
	}

	function run(id) {
		runnerConfig.update((c) => ({ ...c, testID: id }));
		triggerRun(id);
	}

	function runSuite(suite) {
		run(suiteIds(suite)[0]);
	}

	async function copyId(id) {
		await copyText(id);
		copiedIds.add(id);
		copiedIds = copiedIds;
		if (copyTimers.has(id)) clearTimeout(copyTimers.get(id));
		copyTimers.set(
			id,
			setTimeout(() => {
				copiedIds.delete(id);
				copiedIds = copiedIds;
				copyTimers.delete(id);
			}, COPY_TIMEOUT_MS)
		);
	}

	onDestroy(() => {
		for (const timer of copyTimers.values()) clearTimeout(timer);
	});

	$: q = search.trim().toLowerCase();
	$: filtered = suites
		.map((suite) => {
			if (!q) return suite;
			const suiteMatches =
				suite.suiteName.toLowerCase().includes(q) ||
				suiteIds(suite).some((id) => id.toLowerCase().includes(q));
			const matchedTests = suite.tests.filter(
				(t) =>
					t.testCase.toLowerCase().includes(q) ||
					testIds(t).some((id) => id.toLowerCase().includes(q))
			);
			if (!suiteMatches && matchedTests.length === 0) return null;
			return { ...suite, tests: suiteMatches ? suite.tests : matchedTests };
		})
		.filter(Boolean)
		.map((suite) => ({
			...suite,
			tests: [...suite.tests].sort((a, b) => {
				const diff =
					sort.by === 'name'
						? a.testCase.localeCompare(b.testCase)
						: (primaryId(a) ?? '').localeCompare(primaryId(b) ?? '');
				return sort.order === 'asc' ? diff : -diff;
			})
		}))
		.sort((a, b) => {
			const diff =
				sort.by === 'name'
					? a.suiteName.localeCompare(b.suiteName)
					: (suiteIds(a)[0] ?? '').localeCompare(suiteIds(b)[0] ?? '');
			return sort.order === 'asc' ? diff : -diff;
		});

	$: totalTests = suites.reduce((n, s) => n + s.tests.length, 0);
	$: visibleTests = filtered.reduce((n, s) => n + s.tests.length, 0);
</script>

<svelte:head><title>{PAGE_TITLE}</title></svelte:head>

<div class="page-header">
	<div class="header-top">
		<div>
			<h1>{HEADING}</h1>
			<div class="header-learn-more"><LearnMoreLinks /></div>
			<p class="repo-note">{REPO_MANAGED_NOTE}</p>
			<p class="subtitle">
				{#if q}
					{visibleOfTotal(visibleTests, totalTests)}
				{:else}
					{suiteSummary(suites.length, totalTests)}
				{/if}
			</p>
		</div>
	</div>

	<div class="search-row">
		<div class="search-wrap">
			<svg
				class="search-icon"
				width="14"
				height="14"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
			</svg>
			<input
				type="text"
				class="search-input"
				bind:value={search}
				placeholder={SEARCH_PLACEHOLDER}
			/>
			{#if search}
				<button class="search-clear" on:click={() => (search = '')} aria-label={CLEAR_SEARCH_LABEL}>
					<svg width="12" height="12" viewBox="0 0 14 14" fill="none">
						<path
							d="M1 1l12 12M13 1L1 13"
							stroke="currentColor"
							stroke-width="1.5"
							stroke-linecap="round"
						/>
					</svg>
				</button>
			{/if}
		</div>
	</div>
</div>

{#if !q}
	<div class="sort-bar">
		<span class="sort-label">{SORT_BY_LABEL}</span>
		{#each [['id', 'ID'], ['name', 'Name']] as [val, label]}
			<button class="sort-chip" class:active={sort.by === val} on:click={() => applySort(val)}>
				{label}
				{#if sort.by === val}
					<span class="sort-dir">{sort.order === 'asc' ? '↑' : '↓'}</span>
				{/if}
			</button>
		{/each}
	</div>
{/if}

{#if filtered.length === 0}
	<EmptyState message={q ? noMatchMessage(search) : NO_SUITES_MESSAGE} />
{:else}
	<div class="suites">
		{#each filtered as suite, si}
			{@const suiteKey = suiteIds(suite)[0] ?? suite.suiteName}
			{@const suiteOpen = !collapsedSuites.has(suiteKey)}
			<div class="suite" style={stagger(si, 55)}>
				<div class="suite-header" class:collapsed={!suiteOpen}>
					<button
						class="suite-toggle"
						on:click={() => toggleSuite(suiteKey)}
						aria-expanded={suiteOpen}
						aria-label={collapseOrExpandSuiteLabel(suiteOpen)}
					>
						<svg
							width="12"
							height="12"
							viewBox="0 0 24 24"
							fill="none"
							stroke="currentColor"
							stroke-width="2"
							stroke-linecap="round"
							class:rotated={suiteOpen}
						>
							<polyline points="9 18 15 12 9 6" />
						</svg>
					</button>
					<div class="suite-meta">
						<div class="suite-badges">
							{#each suiteIds(suite) as id}
								<button
									class="id-pill"
									class:copied={copiedIds.has(id)}
									on:click={() => copyId(id)}
									title={copiedIds.has(id) ? copiedTitle(id) : copyTitle(id)}
									aria-label={copiedIds.has(id) ? copiedTitle(id) : copyTitle(id)}
								>
									{id}
								</button>
							{/each}
						</div>
						<span class="suite-name">{suite.suiteName}</span>
						<span class="suite-count">{testCountLabel(suite.tests.length)}</span>
					</div>
					<button
						class="run-btn suite-run"
						on:click={() => runSuite(suite)}
						title={RUN_SUITE_LABEL}
					>
						<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" stroke="none">
							<polygon points="5,3 19,12 5,21" />
						</svg>
						{RUN_SUITE_LABEL}
					</button>
				</div>

				{#if suiteOpen}
					<div class="tests" transition:slide={{ duration: 180 }}>
						{#each suite.tests as test, ti}
							{@const pid = primaryId(test)}
							{@const stepsOpen = expandedSteps.has(pid)}
							<div class="test-row" style={stagger(si * 4 + ti, 30)}>
								<div class="test-main">
									<button
										class="run-icon-btn"
										on:click={() => run(pid)}
										title={runIdTitle(pid)}
										aria-label={runTestLabel(test.testCase)}
									>
										<svg
											width="10"
											height="10"
											viewBox="0 0 24 24"
											fill="currentColor"
											stroke="none"
										>
											<polygon points="5,3 19,12 5,21" />
										</svg>
									</button>

									<div class="test-ids">
										{#each testIds(test) as id}
											<button
												class="id-pill"
												class:copied={copiedIds.has(id)}
												on:click={() => copyId(id)}
												title={copiedIds.has(id) ? `Copied ${id}` : `Copy ${id}`}
												aria-label={copiedIds.has(id) ? `Copied ${id}` : `Copy ${id}`}
											>
												{id}
											</button>
										{/each}
									</div>

									<span class="test-name">
										{test.testCase}
										{#if test.type === 'outline'}
											<span class="outline-badge">{OUTLINE_BADGE}</span>
										{/if}
									</span>

									{#if test.steps?.length > 0}
										<button
											class="steps-toggle"
											on:click={() => toggleSteps(pid)}
											aria-expanded={stepsOpen}
										>
											<svg
												width="12"
												height="12"
												viewBox="0 0 24 24"
												fill="none"
												stroke="currentColor"
												stroke-width="2"
												stroke-linecap="round"
												class:rotated={stepsOpen}
											>
												<polyline points="9 18 15 12 9 6" />
											</svg>
											{stepsOpen ? HIDE_LABEL : STEPS_LABEL}
										</button>
									{/if}
								</div>

								{#if stepsOpen && test.steps?.length > 0}
									<div class="steps" transition:slide={{ duration: 180 }}>
										<ol class="step-list">
											{#each test.steps as step}
												<li class="step">{step}</li>
											{/each}
										</ol>

										{#if test.examples}
											<div class="examples">
												<span class="examples-label">{EXAMPLES_LABEL}</span>
												<div class="examples-table-wrap">
													<table class="examples-table">
														<thead>
															<tr
																>{#each test.examples.headers as h}<th>{h}</th>{/each}</tr
															>
														</thead>
														<tbody>
															{#each test.examples.rows as row}
																<tr
																	>{#each row as cell}<td>{cell}</td>{/each}</tr
																>
															{/each}
														</tbody>
													</table>
												</div>
											</div>
										{/if}
									</div>
								{/if}
							</div>
						{/each}
					</div>
				{/if}
			</div>
		{/each}
	</div>
{/if}

<style>
	.page-header {
		margin-bottom: 1.75rem;
		padding-bottom: 1.5rem;
		border-bottom: 1px solid var(--border);
	}

	.repo-note {
		margin-top: 0.35rem;
		max-width: 62ch;
		font-size: 0.8125rem;
		line-height: 1.5;
		color: var(--text-muted);
	}

	.header-learn-more {
		margin-top: 0.4rem;
		margin-bottom: 0.55rem;
	}

	.header-top {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		gap: 1rem;
		margin-bottom: 1.25rem;
	}

	h1 {
		font-size: 2.5rem;
		margin-bottom: 0.25rem;
	}

	.subtitle {
		margin-top: 0.5rem;
		color: var(--text-muted);
		font-size: 0.875rem;
	}

	/* ── Search ── */
	.search-row {
		display: flex;
		gap: 0.75rem;
	}

	.search-wrap {
		position: relative;
		flex: 1;
		max-width: 480px;
	}

	.search-icon {
		position: absolute;
		left: 0.75rem;
		top: 50%;
		transform: translateY(-50%);
		color: var(--text-muted);
		pointer-events: none;
	}

	.search-input {
		width: 100%;
		padding: 0.55rem 0.875rem 0.55rem 2.25rem;
		border: 1px solid var(--border);
		border-radius: var(--radius-md);
		background: var(--bg-subtle);
		color: var(--text);
		font-family: var(--font-body);
		font-size: 0.875rem;
		font-weight: 300;
		outline: none;
		transition:
			border-color var(--duration-fast),
			box-shadow var(--duration-fast);
	}

	.search-input:focus {
		border-color: var(--accent);
		box-shadow: 0 0 0 3px var(--accent-soft);
		background: var(--bg-elevated);
	}

	/* ── Sort bar ── */
	.sort-bar {
		display: flex;
		align-items: center;
		gap: 0.375rem;
		margin: 1.25rem 0;
		flex-wrap: wrap;
	}

	.sort-label {
		font-size: 0.75rem;
		color: var(--text-muted);
		margin-right: 0.25rem;
	}

	.sort-chip {
		display: flex;
		align-items: center;
		gap: 0.25rem;
		height: 28px;
		padding: 0 0.625rem;
		font-family: var(--font-body);
		font-size: 0.8125rem;
		color: var(--text-muted);
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-pill);
		cursor: pointer;
		transition:
			color var(--duration-fast),
			border-color var(--duration-fast),
			background var(--duration-fast);
	}

	.sort-chip:hover {
		color: var(--text);
		border-color: var(--accent);
	}

	.sort-chip.active {
		color: var(--accent);
		border-color: var(--accent);
		background: var(--accent-soft);
	}

	.sort-dir {
		font-size: 0.7rem;
		opacity: 0.8;
	}

	.search-input::placeholder {
		color: var(--text-muted);
	}

	.search-clear {
		position: absolute;
		right: 0.625rem;
		top: 50%;
		transform: translateY(-50%);
		display: flex;
		align-items: center;
		justify-content: center;
		width: 20px;
		height: 20px;
		border-radius: 50%;
		border: none;
		background: var(--border);
		color: var(--text-muted);
		cursor: pointer;
		transition:
			background var(--duration-fast),
			color var(--duration-fast);
	}

	.search-clear:hover {
		background: var(--text-muted);
		color: var(--bg);
	}

	/* ── Suites ── */
	.suites {
		display: flex;
		flex-direction: column;
		gap: 1rem;
	}

	.suite {
		border: 1px solid var(--border);
		border-radius: var(--radius-lg);
		overflow: visible;
		background: var(--bg-elevated);
		animation: fadeUp 0.35s var(--ease-out) both;
	}

	.suite-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 1rem;
		padding: 0.875rem 1.25rem;
		background: var(--bg-subtle);
		border-bottom: 1px solid var(--border);
		border-radius: var(--radius-lg) var(--radius-lg) 0 0;
	}

	.suite-header.collapsed {
		border-bottom: none;
		border-radius: var(--radius-lg);
	}

	.suite-toggle {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 22px;
		height: 22px;
		border: none;
		background: transparent;
		color: var(--text-muted);
		cursor: pointer;
		flex-shrink: 0;
		border-radius: var(--radius-sm);
		transition:
			background var(--duration-fast),
			color var(--duration-fast);
	}

	.suite-toggle:hover {
		background: var(--bg-elevated);
		color: var(--text);
	}

	.suite-toggle svg {
		transition: transform var(--duration-fast) var(--ease-out);
	}
	.suite-toggle svg.rotated {
		transform: rotate(90deg);
	}

	.suite-meta {
		display: flex;
		align-items: center;
		gap: 0.625rem;
		flex: 1;
		min-width: 0;
	}

	.suite-badges {
		display: flex;
		gap: 0.25rem;
		flex-shrink: 0;
	}

	.suite-name {
		font-size: 0.9rem;
		font-weight: 400;
		color: var(--text);
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.suite-count {
		font-size: 0.75rem;
		color: var(--text-muted);
		flex-shrink: 0;
	}

	.run-btn {
		display: inline-flex;
		align-items: center;
		gap: 0.35rem;
		font-family: var(--font-body);
		font-size: 0.75rem;
		font-weight: 400;
		padding: 0.3rem 0.75rem;
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		background: var(--bg-elevated);
		color: var(--text-muted);
		cursor: pointer;
		white-space: nowrap;
		flex-shrink: 0;
		transition:
			background var(--duration-fast),
			color var(--duration-fast),
			border-color var(--duration-fast);
	}

	.run-btn:hover {
		background: var(--accent-soft);
		color: var(--accent);
		border-color: var(--accent);
	}

	/* ── Tests ── */
	.tests {
		display: flex;
		flex-direction: column;
	}

	.test-row {
		border-bottom: 1px solid var(--border);
		animation: fadeUp 0.3s var(--ease-out) both;
	}

	.test-row:last-child {
		border-bottom: none;
	}

	.test-main {
		display: flex;
		align-items: center;
		gap: 0.625rem;
		padding: 0.75rem 1.25rem;
	}

	.run-icon-btn {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 24px;
		height: 24px;
		border-radius: 50%;
		border: 1px solid var(--border);
		background: transparent;
		color: var(--text-muted);
		cursor: pointer;
		flex-shrink: 0;
		transition:
			background var(--duration-fast),
			color var(--duration-fast),
			border-color var(--duration-fast);
	}

	.run-icon-btn:hover {
		background: var(--accent);
		color: var(--white);
		border-color: var(--accent);
	}

	.test-ids {
		display: flex;
		gap: 0.25rem;
		flex-shrink: 0;
	}

	.id-pill {
		position: relative;
		font-size: 0.68rem;
		font-weight: 500;
		letter-spacing: 0.04em;
		color: var(--accent);
		background: var(--accent-soft);
		border: none;
		border-radius: var(--radius-pill);
		padding: 0.15rem 0.55rem;
		cursor: pointer;
		font-family: 'JetBrains Mono', monospace;
		transition:
			background var(--duration-fast),
			color var(--duration-fast),
			filter var(--duration-fast);
	}

	.id-pill:hover {
		filter: brightness(0.92);
	}
	.id-pill.copied {
		color: var(--pass);
		background: var(--pass-soft);
	}

	.id-pill.copied::after {
		content: 'Copied';
		position: absolute;
		left: 50%;
		bottom: calc(100% + 6px);
		z-index: 50;
		transform: translateX(-50%);
		padding: 0.16rem 0.42rem;
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		background: var(--bg-elevated);
		color: var(--pass);
		box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
		font-family: var(--font-body);
		font-size: 0.65rem;
		font-weight: 500;
		letter-spacing: 0;
		pointer-events: none;
		animation: copiedPop 1.4s var(--ease-out) both;
	}

	.test-name {
		flex: 1;
		font-size: 0.875rem;
		color: var(--text);
		min-width: 0;
	}

	.outline-badge {
		display: inline-block;
		font-size: 0.62rem;
		font-weight: 500;
		letter-spacing: 0.06em;
		text-transform: uppercase;
		background: var(--warn-soft);
		color: var(--warn);
		padding: 0.1rem 0.4rem;
		border-radius: var(--radius-pill);
		margin-left: 0.4rem;
		vertical-align: middle;
	}

	.steps-toggle {
		display: inline-flex;
		align-items: center;
		gap: 0.2rem;
		font-family: var(--font-body);
		font-size: 0.72rem;
		font-weight: 400;
		color: var(--text-muted);
		background: transparent;
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		padding: 0.2rem 0.5rem;
		cursor: pointer;
		flex-shrink: 0;
		transition:
			background var(--duration-fast),
			color var(--duration-fast);
	}

	.steps-toggle:hover {
		background: var(--bg-subtle);
		color: var(--text);
	}

	.steps-toggle svg {
		transition: transform var(--duration-fast) var(--ease-out);
	}
	.steps-toggle svg.rotated {
		transform: rotate(90deg);
	}

	/* ── Steps panel ── */
	.steps {
		padding: 0.75rem 1.25rem 0.875rem 3.75rem;
		background: var(--bg-subtle);
		border-top: 1px solid var(--border);
	}

	.step-list {
		list-style: none;
		display: flex;
		flex-direction: column;
		gap: 0.3rem;
	}

	.step {
		font-size: 0.8125rem;
		color: var(--text-muted);
		font-family: 'JetBrains Mono', monospace;
		line-height: 1.5;
		padding-left: 1rem;
		position: relative;
	}

	.step::before {
		content: '›';
		position: absolute;
		left: 0;
		color: var(--accent);
		font-family: var(--font-body);
	}

	/* ── Examples table ── */
	.examples {
		margin-top: 0.75rem;
		padding-top: 0.75rem;
		border-top: 1px dashed var(--border);
	}

	.examples-label {
		display: block;
		font-size: 0.68rem;
		font-weight: 500;
		letter-spacing: 0.07em;
		text-transform: uppercase;
		color: var(--text-muted);
		margin-bottom: 0.5rem;
	}

	.examples-table-wrap {
		overflow-x: auto;
	}

	.examples-table {
		border-collapse: collapse;
		font-size: 0.78rem;
		font-family: 'JetBrains Mono', monospace;
		width: auto;
	}

	.examples-table th {
		text-align: left;
		padding: 0.3rem 0.75rem;
		font-size: 0.7rem;
		letter-spacing: 0.06em;
		text-transform: uppercase;
		color: var(--text-muted);
		border-bottom: 1px solid var(--border);
		font-family: var(--font-body);
		font-weight: 500;
	}

	.examples-table td {
		padding: 0.3rem 0.75rem;
		color: var(--text-muted);
		border-bottom: 1px solid var(--border);
	}

	.examples-table tbody tr:last-child td {
		border-bottom: none;
	}

	@keyframes copiedPop {
		0% {
			opacity: 0;
			transform: translate(-50%, 4px) scale(0.96);
		}
		12%,
		78% {
			opacity: 1;
			transform: translate(-50%, 0) scale(1);
		}
		100% {
			opacity: 0;
			transform: translate(-50%, -2px) scale(0.98);
		}
	}

	@media (max-width: 640px) {
		h1 {
			font-size: 1.9rem;
		}

		.header-top {
			flex-direction: column;
			align-items: stretch;
			gap: 0.875rem;
		}

		.search-row {
			flex-wrap: wrap;
		}

		.suite-header {
			flex-wrap: wrap;
			gap: 0.6rem;
			padding: 0.75rem 1rem;
		}

		.test-main {
			flex-wrap: wrap;
			padding: 0.7rem 1rem;
		}

		.test-name {
			flex-basis: 100%;
			order: 1;
		}
	}
</style>
