<!--
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 -->

<script>
	import { onMount, onDestroy } from 'svelte';
	import { get } from 'svelte/store';
	import { page } from '$app/stores';
	import { fly } from 'svelte/transition';
	import {
		fetchRun,
		updateRun,
		fetchAllSuitesWithCases,
		recordEntryResult,
		assignEntry,
		fetchMembers,
		downloadTestCaseExport
	} from '$lib/api/repository';
	import { runsVersion, socket } from '$lib/stores/runner';
	import { SOCKET_EVENTS } from '$lib/socketEvents';
	import { auth } from '$lib/stores/auth';
	import Button from '$lib/components/ui/Button.svelte';
	import Modal from '$lib/components/ui/Modal.svelte';
	import { notify, notifyProgress } from '$lib/stores/notifications';
	import EmptyState from '$lib/components/ui/EmptyState.svelte';
	import AutomatedBadge from '$lib/components/ui/AutomatedBadge.svelte';
	import AssigneePicker from '$lib/components/ui/AssigneePicker.svelte';
	import PriorityBadge from '$lib/components/ui/PriorityBadge.svelte';
	import CaseIdChip from '$lib/components/ui/CaseIdChip.svelte';
	import ResultChip from '$lib/components/ui/ResultChip.svelte';
	import ExportMenu from '$lib/components/ui/ExportMenu.svelte';
	import {
		CANCEL_LABEL,
		SAVE_LABEL,
		SAVING_LABEL,
		LOADING_LABEL,
		exportedToast,
		exportFailedToast,
		exportingToast
	} from '$lib/copy/common';
	import {
		TEST_REPOSITORY_BREADCRUMB,
		TITLE_LABEL,
		EDIT_RUN_MODAL_TITLE,
		EDIT_RUN_TITLE,
		REOPEN_LABEL,
		START_EXECUTION_LABEL,
		STOP_EXECUTION_LABEL,
		EDIT_RUN_BACK_LABEL,
		MARK_COMPLETE_LABEL,
		BUILD_TAB_LABEL,
		EXECUTE_TAB_LABEL,
		IN_THIS_RUN_LABEL,
		LOCKED_BADGE,
		NO_CASES_IN_RUN_MESSAGE,
		SUITE_BROWSER_LABEL,
		SEARCH_CASES_PLACEHOLDER,
		NO_MATCHING_CASES,
		NO_CASES_IN_SUITE,
		ALL_CASES_ADDED,
		NO_SUITES_AVAILABLE,
		NOT_IN_PROGRESS_BANNER,
		TOGGLE_STEPS_TITLE,
		ASSIGN_TO_ME_LABEL,
		UNASSIGN_LABEL,
		IN_PROGRESS_LABEL,
		PASS_LABEL,
		FAIL_LABEL,
		BLOCKED_LABEL,
		SKIP_LABEL,
		RESET_TO_PENDING_TITLE,
		RESET_LABEL,
		resultLockedHint,
		RESULT_UNASSIGNED_HINT,
		FAILED_TO_LOAD_DATA,
		FAILED_TO_ADD_CASE,
		RUN_UPDATED_TOAST,
		RUN_MARKED_COMPLETE_TOAST,
		RUN_REOPENED_TOAST,
		EXPORT_RUN_WHAT,
		runDetailTitle,
		passedCount,
		failedCount,
		remainingCount,
		stepDataLabel,
		stepExpectedLabel
	} from '$lib/copy/repository';

	const runId = $page.params.id;

	/** @type {'build' | 'execute'} */
	let mode = 'build';

	let run = null;
	let suites = [];
	let members = [];
	let loading = true;
	let assigning = null;

	$: currentUserId = $auth?.user?.id ?? null;

	let search = '';
	let expandedSuites = new Set();

	const PRIORITY_ORDER = { Critical: 0, High: 1, Medium: 2, Low: 3 };

	let entriesSort = (() => {
		try {
			const v = sessionStorage.getItem('plum:run:entries:sort');
			if (v) return JSON.parse(v);
		} catch {}
		return { by: 'order', order: 'asc' };
	})();

	$: sortedEntries = (() => {
		if (!run) return [];
		const list = [...run.entries];
		const dir = entriesSort.order === 'asc' ? 1 : -1;
		if (entriesSort.by === 'name')
			return list.sort((a, b) => dir * a.case.title.localeCompare(b.case.title));
		if (entriesSort.by === 'priority')
			return list.sort(
				(a, b) =>
					dir * ((PRIORITY_ORDER[a.case.priority] ?? 99) - (PRIORITY_ORDER[b.case.priority] ?? 99))
			);
		if (entriesSort.by === 'status')
			return list.sort((a, b) => dir * a.status.localeCompare(b.status));
		if (entriesSort.by === 'suite')
			return list.sort(
				(a, b) => dir * (a.case.suite?.name ?? '').localeCompare(b.case.suite?.name ?? '')
			);
		return list.sort((a, b) => dir * (a.order - b.order));
	})();

	function applyEntriesSort(by) {
		if (entriesSort.by === by) {
			entriesSort.order = entriesSort.order === 'asc' ? 'desc' : 'asc';
		} else {
			entriesSort = { by, order: 'asc' };
		}
		try {
			sessionStorage.setItem('plum:run:entries:sort', JSON.stringify(entriesSort));
		} catch {}
	}

	let dragOver = false;
	let dragEntryId = null;
	let dragOverEntryId = null;

	let executingEntryId = null;
	let entryNote = '';
	let expandedExecEntries = new Set();

	let editRunOpen = false;
	let editRunForm = {};
	let editRunSaving = false;

	function toggleExecSteps(entryId) {
		if (expandedExecEntries.has(entryId)) expandedExecEntries.delete(entryId);
		else expandedExecEntries.add(entryId);
		expandedExecEntries = new Set(expandedExecEntries);
	}

	onMount(async () => {
		try {
			[run, suites, members] = await Promise.all([
				fetchRun(runId),
				fetchAllSuitesWithCases(),
				fetchMembers()
			]);
			expandedSuites = new Set(suites.map((s) => s.id));
			if (run.status === 'in-progress') mode = 'execute';
		} catch (e) {
			notify('error', FAILED_TO_LOAD_DATA);
		} finally {
			loading = false;
		}
	});

	// Live collaboration: everyone on this run's page shares a socket room, so one
	// person's assignment / result / edit lands on the others without a refresh.
	function onTestRunChanged({ runId: rid, entry, reload }) {
		if (rid !== runId || !run) return;
		if (reload) {
			const prevStatus = run.status;
			fetchRun(runId).then((r) => {
				run = r;
				if (prevStatus !== r.status) mode = r.status === 'in-progress' ? 'execute' : 'build';
			});
			return;
		}
		if (entry) {
			run = {
				...run,
				entries: run.entries.map((e) => (e.id === entry.id ? { ...e, ...entry } : e))
			};
		}
	}

	let _joinedRunId = null;
	$: if ($socket && runId && _joinedRunId !== runId) {
		if (_joinedRunId) $socket.emit(SOCKET_EVENTS.TEST_RUN_LEAVE, { runId: _joinedRunId });
		$socket.emit(SOCKET_EVENTS.TEST_RUN_JOIN, { runId });
		$socket.off(SOCKET_EVENTS.TEST_RUN_CHANGED, onTestRunChanged);
		$socket.on(SOCKET_EVENTS.TEST_RUN_CHANGED, onTestRunChanged);
		_joinedRunId = runId;
	}

	onDestroy(() => {
		const s = get(socket);
		if (s && _joinedRunId) {
			s.emit(SOCKET_EVENTS.TEST_RUN_LEAVE, { runId: _joinedRunId });
			s.off(SOCKET_EVENTS.TEST_RUN_CHANGED, onTestRunChanged);
		}
	});

	async function handleAssignEntry(entryId, userId) {
		assigning = entryId;
		try {
			const updated = await assignEntry(entryId, userId || null);
			run = {
				...run,
				entries: run.entries.map((e) =>
					e.id === entryId
						? { ...e, assignedToId: updated.assignedToId, assignedTo: updated.assignedTo }
						: e
				)
			};
		} catch (e) {
			notify('error', e.message);
		} finally {
			assigning = null;
		}
	}

	$: runCaseIds = new Set(run?.entries.map((e) => e.case.id) ?? []);

	$: filteredSuites = suites
		.map((suite) => ({
			...suite,
			_totalCases: (suite.cases ?? []).length,
			cases: (suite.cases ?? []).filter(
				(tc) =>
					!runCaseIds.has(tc.id) &&
					(!search ||
						suite.displayId.toLowerCase().includes(search.toLowerCase()) ||
						suite.name.toLowerCase().includes(search.toLowerCase()) ||
						tc.title.toLowerCase().includes(search.toLowerCase()) ||
						tc.displayId.toLowerCase().includes(search.toLowerCase()))
			)
		}))
		.filter(
			(suite) =>
				!search ||
				suite.cases.length > 0 ||
				suite.displayId.toLowerCase().includes(search.toLowerCase()) ||
				suite.name.toLowerCase().includes(search.toLowerCase())
		);

	// The build list autosaves: every add / remove / reorder persists the run's
	// case set immediately, so there's no separate Save step.
	async function persistEntries() {
		const caseIds = run.entries.map((e) => e.case.id);
		await updateRun(runId, { caseIds });
		run = await fetchRun(runId);
	}

	async function addCase(tc) {
		if (!run || runCaseIds.has(tc.id)) return;
		const previous = run;
		const entry = {
			id: `tmp-${tc.id}`,
			order: run.entries.length,
			status: 'pending',
			notes: '',
			executedAt: null,
			executedBy: null,
			case: tc
		};
		run = { ...run, entries: [...run.entries, entry] };
		try {
			await persistEntries();
		} catch (e) {
			run = previous;
			notify('error', FAILED_TO_ADD_CASE);
		}
	}

	async function removeEntry(entryId) {
		const previous = run;
		run = { ...run, entries: run.entries.filter((e) => e.id !== entryId) };
		try {
			await persistEntries();
		} catch (e) {
			run = previous;
			notify('error', e.message);
		}
	}

	async function handleUpdateRun() {
		editRunSaving = true;
		try {
			const updated = await updateRun(runId, editRunForm);
			run = { ...run, ...updated };
			editRunOpen = false;
			notify('success', RUN_UPDATED_TOAST);
		} catch (e) {
			notify('error', e.message);
		} finally {
			editRunSaving = false;
		}
	}

	async function handleStartExecution() {
		try {
			await persistEntries();
			await updateRun(runId, { status: 'in-progress' });
			run = { ...run, status: 'in-progress' };
			mode = 'execute';
		} catch (e) {
			notify('error', e.message);
		}
	}

	async function handleMarkEntry(entry, status) {
		executingEntryId = entry.id;
		try {
			const updated = await recordEntryResult(entry.id, { status, notes: entryNote });
			run = {
				...run,
				entries: run.entries.map((e) => (e.id === entry.id ? { ...e, ...updated, status } : e))
			};
			entryNote = '';
		} catch (e) {
			notify('error', e.message);
		} finally {
			executingEntryId = null;
		}
	}

	async function handleStopExecution() {
		try {
			await updateRun(runId, { status: 'backlog' });
			run = { ...run, status: 'backlog' };
			mode = 'build';
			runsVersion.update((v) => v + 1);
		} catch (e) {
			notify('error', e.message);
		}
	}

	async function handleCompleteRun() {
		try {
			await updateRun(runId, { status: 'complete' });
			run = { ...run, status: 'complete' };
			runsVersion.update((v) => v + 1);
			notify('success', RUN_MARKED_COMPLETE_TOAST);
		} catch (e) {
			notify('error', e.message);
		}
	}

	let exporting = false;
	async function handleExportRun(format) {
		exporting = true;
		const settle = notifyProgress(exportingToast(EXPORT_RUN_WHAT));
		try {
			await downloadTestCaseExport('run', runId, format);
			settle('success', exportedToast(EXPORT_RUN_WHAT));
		} catch {
			settle('error', exportFailedToast('this run'));
		} finally {
			exporting = false;
		}
	}

	async function handleReopenRun() {
		try {
			await updateRun(runId, { status: 'backlog' });
			run = { ...run, status: 'backlog' };
			mode = 'build';
			runsVersion.update((v) => v + 1);
			notify('success', RUN_REOPENED_TOAST);
		} catch (e) {
			notify('error', e.message);
		}
	}

	$: isLocked = run?.status === 'complete';

	function onDragStart(e, entryId) {
		dragEntryId = entryId;
		e.dataTransfer.effectAllowed = 'move';
	}

	function onDragOver(e, entryId) {
		e.preventDefault();
		dragOverEntryId = entryId;
	}

	async function onDrop(e, targetEntryId) {
		e.preventDefault();
		if (!dragEntryId || dragEntryId === targetEntryId) return;
		const previous = run;
		const entries = [...run.entries];
		const fromIdx = entries.findIndex((e) => e.id === dragEntryId);
		const toIdx = entries.findIndex((e) => e.id === targetEntryId);
		const [moved] = entries.splice(fromIdx, 1);
		entries.splice(toIdx, 0, moved);
		run = { ...run, entries };
		dragEntryId = null;
		dragOverEntryId = null;
		try {
			await persistEntries();
		} catch (err) {
			run = previous;
			notify('error', err.message);
		}
	}

	$: completedCount = run?.entries.filter((e) => e.status !== 'pending').length ?? 0;
	$: totalCount = run?.entries.length ?? 0;
	$: passCount = run?.entries.filter((e) => e.status === 'pass').length ?? 0;
	$: failCount = run?.entries.filter((e) => e.status === 'fail').length ?? 0;
</script>

<svelte:head><title>{runDetailTitle(run)}</title></svelte:head>

<Modal bind:open={editRunOpen} title={EDIT_RUN_MODAL_TITLE}>
	<div class="form-fields">
		<div class="field">
			<label class="field-label" for="er-title">{TITLE_LABEL}</label>
			<input id="er-title" type="text" class="field-input" bind:value={editRunForm.title} />
		</div>
		<div class="modal-actions">
			<Button on:click={handleUpdateRun} disabled={editRunSaving}>
				{editRunSaving ? SAVING_LABEL : SAVE_LABEL}
			</Button>
			<Button variant="ghost" on:click={() => (editRunOpen = false)}>{CANCEL_LABEL}</Button>
		</div>
	</div>
</Modal>

<div class="breadcrumb">
	<a href="/test-repository" class="bc-link">{TEST_REPOSITORY_BREADCRUMB}</a>
	<span class="bc-sep">›</span>
	<span class="bc-current">{run?.title ?? '…'}</span>
</div>

{#if loading}
	<div class="loading-state">{LOADING_LABEL}</div>
{:else if run}
	<div class="run-header">
		<div class="run-header-left">
			<h1 class="run-title">{run.title}</h1>
			<span class="run-status-badge {run.status}">{run.status}</span>
			<button
				class="icon-btn"
				title={EDIT_RUN_TITLE}
				on:click={() => {
					editRunForm = { title: run.title };
					editRunOpen = true;
				}}
			>
				<svg
					width="14"
					height="14"
					viewBox="0 0 24 24"
					fill="none"
					stroke="currentColor"
					stroke-width="2"
					stroke-linecap="round"
					stroke-linejoin="round"
					><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path
						d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"
					/></svg
				>
			</button>
		</div>
		<div class="run-header-actions">
			{#if isLocked}
				<ExportMenu busy={exporting} on:select={(e) => handleExportRun(e.detail)} />
				<Button variant="ghost" on:click={handleReopenRun}>{REOPEN_LABEL}</Button>
			{:else if mode === 'build'}
				{#if run.entries.length > 0}
					<Button on:click={handleStartExecution}>{START_EXECUTION_LABEL}</Button>
				{/if}
			{:else if run.status === 'in-progress'}
				<Button variant="ghost" on:click={handleStopExecution}>{STOP_EXECUTION_LABEL}</Button>
				<Button variant="ghost" on:click={() => (mode = 'build')}>{EDIT_RUN_BACK_LABEL}</Button>
				<Button on:click={handleCompleteRun}>{MARK_COMPLETE_LABEL}</Button>
			{:else}
				<Button variant="ghost" on:click={() => (mode = 'build')}>{EDIT_RUN_BACK_LABEL}</Button>
			{/if}
		</div>
	</div>

	<!-- Mode tabs -->
	<div class="mode-tabs">
		<button class="mode-tab" class:active={mode === 'build'} on:click={() => (mode = 'build')}>
			{BUILD_TAB_LABEL}
		</button>
		<button class="mode-tab" class:active={mode === 'execute'} on:click={() => (mode = 'execute')}>
			{EXECUTE_TAB_LABEL}
			{#if totalCount > 0}
				<span class="exec-progress">{completedCount}/{totalCount}</span>
			{/if}
		</button>
	</div>

	{#if mode === 'build'}
		<div
			class="builder-workspace"
			class:locked-workspace={isLocked}
			transition:fly={{ y: 4, duration: 150 }}
		>
			<!-- Left: run entries -->
			<div class="builder-panel left-panel">
				<div class="builder-panel-head">
					<h2 class="builder-panel-title">{IN_THIS_RUN_LABEL}</h2>
					<span class="count-chip">{run.entries.length}</span>
					{#if isLocked}
						<span class="locked-badge">{LOCKED_BADGE}</span>
					{/if}
				</div>

				{#if run.entries.length === 0}
					<EmptyState message={NO_CASES_IN_RUN_MESSAGE} size="sm" />
				{:else}
					<div class="entry-sort-bar">
						{#each [['order', 'Order'], ['name', 'Name'], ['priority', 'Priority'], ['status', 'Status'], ['suite', 'Suite']] as [val, label]}
							<button
								class="entry-sort-chip"
								class:active={entriesSort.by === val}
								on:click={() => applyEntriesSort(val)}
							>
								{label}{#if entriesSort.by === val}<span class="entry-sort-dir"
										>{entriesSort.order === 'asc' ? ' ↑' : ' ↓'}</span
									>{/if}
							</button>
						{/each}
					</div>
					<div class="entry-list" role="list">
						{#each sortedEntries as entry (entry.id)}
							<div
								class="entry-row"
								class:entry-locked={isLocked}
								role="listitem"
								draggable={!isLocked && entriesSort.by === 'order'}
								on:dragstart={isLocked || entriesSort.by !== 'order'
									? null
									: (e) => onDragStart(e, entry.id)}
								on:dragover={isLocked || entriesSort.by !== 'order'
									? null
									: (e) => onDragOver(e, entry.id)}
								on:dragleave={isLocked || entriesSort.by !== 'order'
									? null
									: () => (dragOverEntryId = null)}
								on:drop={isLocked || entriesSort.by !== 'order' ? null : (e) => onDrop(e, entry.id)}
								class:dragging={dragEntryId === entry.id}
								class:drag-over={dragOverEntryId === entry.id}
							>
								{#if !isLocked && entriesSort.by === 'order'}
									<svg
										class="drag-handle"
										width="12"
										height="12"
										viewBox="0 0 24 24"
										fill="currentColor"
									>
										<circle cx="9" cy="5" r="1.5" /><circle cx="15" cy="5" r="1.5" />
										<circle cx="9" cy="12" r="1.5" /><circle cx="15" cy="12" r="1.5" />
										<circle cx="9" cy="19" r="1.5" /><circle cx="15" cy="19" r="1.5" />
									</svg>
								{/if}
								<div class="entry-info">
									<div class="entry-badges">
										<CaseIdChip id={entry.case.displayId} />
										<PriorityBadge priority={entry.case.priority} />
									</div>
									<p class="entry-title">{entry.case.title}</p>
									<span class="entry-suite">{entry.case.suite?.name ?? ''}</span>
								</div>
								{#if entry.case.isAutomated}
									<AutomatedBadge />
								{:else}
									<AssigneePicker
										{members}
										value={entry.assignedToId}
										name={entry.assignedTo?.name}
										disabled={assigning === entry.id}
										on:change={(e) => handleAssignEntry(entry.id, e.detail)}
									/>
								{/if}
								{#if !isLocked}
									<button class="icon-btn danger" on:click={() => removeEntry(entry.id)}>
										<svg width="11" height="11" viewBox="0 0 14 14" fill="none"
											><path
												d="M1 1l12 12M13 1L1 13"
												stroke="currentColor"
												stroke-width="1.5"
												stroke-linecap="round"
											/></svg
										>
									</button>
								{/if}
							</div>
						{/each}
					</div>
				{/if}
			</div>

			<!-- Right: suite browser (hidden when locked) -->
			{#if !isLocked}
				<div class="builder-panel right-panel">
					<div class="builder-panel-head">
						<h2 class="builder-panel-title">{SUITE_BROWSER_LABEL}</h2>
						<input
							type="text"
							class="search-input"
							bind:value={search}
							placeholder={SEARCH_CASES_PLACEHOLDER}
						/>
					</div>

					<div class="suite-browser">
						{#each filteredSuites as suite (suite.id)}
							<div class="browser-suite">
								<button
									class="browser-suite-header"
									on:click={() => {
										if (expandedSuites.has(suite.id)) expandedSuites.delete(suite.id);
										else expandedSuites.add(suite.id);
										expandedSuites = new Set(expandedSuites);
									}}
								>
									<svg
										class="chevron"
										class:open={expandedSuites.has(suite.id)}
										width="12"
										height="12"
										viewBox="0 0 24 24"
										fill="none"
										stroke="currentColor"
										stroke-width="2"
										stroke-linecap="round"><polyline points="9 18 15 12 9 6" /></svg
									>
									<span class="browser-suite-name">{suite.name}</span>
									<span class="browser-suite-count">{suite.cases?.length ?? 0}</span>
								</button>
								{#if expandedSuites.has(suite.id) && suite.cases?.length > 0}
									<div class="browser-cases" transition:fly={{ y: -4, duration: 120 }}>
										{#each suite.cases as tc (tc.id)}
											<button class="browser-case" on:click={() => addCase(tc)}>
												<CaseIdChip id={tc.displayId} small />
												<span class="browser-case-title">{tc.title}</span>
												<PriorityBadge priority={tc.priority} small />
												{#if tc.isAutomated}
													<AutomatedBadge />
												{/if}
											</button>
										{/each}
									</div>
								{:else if expandedSuites.has(suite.id)}
									<p class="browser-empty">
										{search
											? NO_MATCHING_CASES
											: suite._totalCases === 0
												? NO_CASES_IN_SUITE
												: ALL_CASES_ADDED}
									</p>
								{/if}
							</div>
						{/each}
						{#if filteredSuites.length === 0}
							<p class="browser-empty">{NO_SUITES_AVAILABLE}</p>
						{/if}
					</div>
				</div>
			{/if}
		</div>
	{:else}
		<div class="execute-workspace" transition:fly={{ y: 4, duration: 150 }}>
			{#if run.status !== 'in-progress' && !isLocked}
				<div class="exec-locked-banner">
					{NOT_IN_PROGRESS_BANNER}
				</div>
			{/if}
			<!-- Progress bar -->
			{#if totalCount > 0}
				<div class="progress-bar-wrap">
					<div class="progress-stats">
						<span class="stat pass">{passedCount(passCount)}</span>
						<span class="stat fail">{failedCount(failCount)}</span>
						<span class="stat muted">{remainingCount(totalCount - completedCount)}</span>
					</div>
					<div class="progress-bar">
						<div class="progress-fill pass" style="width: {(passCount / totalCount) * 100}%"></div>
						<div class="progress-fill fail" style="width: {(failCount / totalCount) * 100}%"></div>
					</div>
				</div>
			{/if}

			<div class="execute-list">
				{#each run.entries as entry (entry.id)}
					{@const claimed = entry.assignedTo?.id === currentUserId}
					{@const resultLocked = !entry.case.isAutomated && !claimed}
					{@const resultLockHint = entry.assignedTo
						? resultLockedHint(entry.assignedTo.name)
						: RESULT_UNASSIGNED_HINT}
					{@const showResultButtons =
						!isLocked && run.status === 'in-progress' && (!entry.case.isAutomated || claimed)}
					<div class="execute-row" class:expanded={executingEntryId === entry.id}>
						<div class="execute-row-main">
							<div class="exec-info">
								{#if entry.case.steps?.length > 0}
									<button
										class="exec-chevron"
										on:click={() => toggleExecSteps(entry.id)}
										title={TOGGLE_STEPS_TITLE}
									>
										<svg
											class="chevron"
											class:open={expandedExecEntries.has(entry.id)}
											width="12"
											height="12"
											viewBox="0 0 24 24"
											fill="none"
											stroke="currentColor"
											stroke-width="2"
											stroke-linecap="round"><polyline points="9 18 15 12 9 6" /></svg
										>
									</button>
								{/if}
								<CaseIdChip id={entry.case.displayId} />
								{#if entry.case.isAutomated}<AutomatedBadge />{/if}
								<div>
									<p class="exec-title">{entry.case.title}</p>
									<span class="exec-suite">{entry.case.suite?.name ?? ''}</span>
								</div>
							</div>
							<div class="exec-actions">
								{#if entry.assignedTo || !isLocked}
									<div class="exec-assignee-row">
										{#if entry.assignedTo}
											<span class="exec-assignee-name">{entry.assignedTo.name}</span>
										{/if}
										{#if !isLocked && claimed}
											<button
												class="exec-assign-me"
												on:click={() => handleAssignEntry(entry.id, null)}
												disabled={assigning === entry.id}
											>
												{UNASSIGN_LABEL}
											</button>
										{:else if !isLocked}
											<button
												class="exec-assign-me"
												on:click={() => handleAssignEntry(entry.id, currentUserId)}
												disabled={assigning === entry.id}
											>
												{ASSIGN_TO_ME_LABEL}
											</button>
										{/if}
									</div>
									<div class="exec-assignee-divider"></div>
								{/if}
								{#if !showResultButtons}
									<ResultChip status={entry.status} />
								{:else if entry.status === 'pending' || entry.status === 'in-progress'}
									<div
										class="exec-btns"
										class:locked={resultLocked}
										title={resultLocked ? resultLockHint : null}
									>
										<button
											class="exec-btn in-progress"
											class:active={entry.status === 'in-progress'}
											disabled={resultLocked}
											on:click={() =>
												handleMarkEntry(
													entry,
													entry.status === 'in-progress' ? 'pending' : 'in-progress'
												)}>{IN_PROGRESS_LABEL}</button
										>
										<button
											class="exec-btn pass"
											disabled={resultLocked}
											on:click={() => handleMarkEntry(entry, 'pass')}>{PASS_LABEL}</button
										>
										<button
											class="exec-btn fail"
											disabled={resultLocked}
											on:click={() => handleMarkEntry(entry, 'fail')}>{FAIL_LABEL}</button
										>
										<button
											class="exec-btn warn"
											disabled={resultLocked}
											on:click={() => handleMarkEntry(entry, 'blocked')}>{BLOCKED_LABEL}</button
										>
										<button
											class="exec-btn muted"
											disabled={resultLocked}
											on:click={() => handleMarkEntry(entry, 'skip')}>{SKIP_LABEL}</button
										>
									</div>
								{:else}
									<div class="exec-btns">
										<ResultChip status={entry.status} />
										<button
											class="exec-reset"
											disabled={resultLocked}
											title={resultLocked ? resultLockHint : RESET_TO_PENDING_TITLE}
											on:click={() => handleMarkEntry(entry, 'pending')}>{RESET_LABEL}</button
										>
									</div>
								{/if}
							</div>
						</div>

						<!-- Step viewer for current entry -->
						{#if entry.case.steps && entry.case.steps.length > 0 && expandedExecEntries.has(entry.id)}
							<div class="exec-steps">
								{#each entry.case.steps as step, i}
									<div class="exec-step">
										<span class="exec-step-num">{i + 1}</span>
										<div class="exec-step-body">
											<p class="exec-step-action">{step.action}</p>
											{#if step.testData}
												<p class="exec-step-data">{stepDataLabel(step.testData)}</p>
											{/if}
											{#if step.expectedOutput}
												<p class="exec-step-expected">{stepExpectedLabel(step.expectedOutput)}</p>
											{/if}
										</div>
									</div>
								{/each}
							</div>
						{/if}
					</div>
				{/each}
			</div>
		</div>
	{/if}
{/if}

<style>
	.loading-state {
		font-size: 0.875rem;
		color: var(--text-muted);
		padding: 3rem 0;
	}

	.breadcrumb {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		font-size: 0.8125rem;
		color: var(--text-muted);
		margin-bottom: 1.5rem;
	}

	.bc-link {
		color: var(--accent);
		text-decoration: none;
	}
	.bc-link:hover {
		text-decoration: underline;
	}
	.bc-sep {
		color: var(--border);
	}

	/* ── Run header ── */
	.run-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 1rem;
		margin-bottom: 1.5rem;
		padding-bottom: 1.25rem;
		border-bottom: 1px solid var(--border);
	}

	.run-header-left {
		display: flex;
		align-items: center;
		gap: 0.75rem;
	}

	.run-title {
		font-size: 1.75rem;
		font-weight: 600;
		color: var(--text);
	}

	.run-status-badge {
		font-size: 0.7rem;
		font-weight: 500;
		text-transform: capitalize;
		border-radius: var(--radius-pill);
		padding: 0.2rem 0.6rem;
		border: 1px solid var(--border);
		color: var(--text-muted);
		background: var(--bg-subtle);
	}

	.run-status-badge.complete {
		background: var(--pass-soft);
		color: var(--pass);
		border-color: var(--pass);
	}

	.run-status-badge.in-progress {
		background: var(--accent-soft);
		color: var(--accent);
		border-color: var(--accent);
	}

	.run-status-badge.backlog {
		background: var(--bg-subtle);
		color: var(--text-muted);
		border-color: var(--border);
	}

	.locked-badge {
		font-size: 0.62rem;
		font-weight: 600;
		letter-spacing: 0.07em;
		text-transform: uppercase;
		color: var(--text-muted);
		background: var(--bg-subtle);
		border: 1px solid var(--border);
		border-radius: var(--radius-pill);
		padding: 0.1rem 0.45rem;
		margin-left: auto;
	}

	.locked-workspace {
		grid-template-columns: 1fr;
	}

	.entry-row.entry-locked {
		cursor: default;
	}
	.entry-row.entry-locked:hover {
		background: var(--bg-elevated);
	}
	.run-status-badge.in-progress {
		background: var(--warn-soft);
		color: var(--warn);
		border-color: var(--warn);
	}

	.run-header-actions {
		display: flex;
		align-items: center;
		gap: 0.5rem;
	}

	/* ── Mode tabs ── */
	.mode-tabs {
		display: flex;
		gap: 0.125rem;
		border-bottom: 1px solid var(--border);
		margin-bottom: 1.5rem;
	}

	.mode-tab {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		padding: 0.5rem 1rem 0.625rem;
		font-family: var(--font-body);
		font-size: 0.875rem;
		color: var(--text-muted);
		background: none;
		border: none;
		border-bottom: 2px solid transparent;
		cursor: pointer;
		margin-bottom: -1px;
		transition:
			color var(--duration-fast),
			border-color var(--duration-fast);
	}

	.mode-tab:hover {
		color: var(--text);
	}
	.mode-tab.active {
		color: var(--accent);
		border-bottom-color: var(--accent);
		font-weight: 500;
	}

	.exec-progress {
		font-size: 0.7rem;
		background: var(--bg-subtle);
		border: 1px solid var(--border);
		border-radius: var(--radius-pill);
		padding: 0.05rem 0.4rem;
		color: var(--text-muted);
	}

	/* ── Builder ── */
	.builder-workspace {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 1.5rem;
		align-items: start;
	}

	.builder-panel {
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-md);
		overflow: hidden;
	}

	.builder-panel-head {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		padding: 0.875rem 1rem;
		border-bottom: 1px solid var(--border);
		background: var(--bg-subtle);
	}

	.builder-panel-title {
		font-size: 0.875rem;
		font-weight: 500;
		color: var(--text);
	}

	.count-chip {
		font-size: 0.7rem;
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-pill);
		padding: 0.05rem 0.4rem;
		color: var(--text-muted);
	}

	.search-input {
		flex: 1;
		height: 28px;
		padding: 0 0.625rem;
		font-family: var(--font-body);
		font-size: 0.8125rem;
		color: var(--text);
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		outline: none;
	}

	.search-input:focus {
		border-color: var(--accent);
	}

	.entry-sort-bar {
		display: flex;
		align-items: center;
		gap: 0.25rem;
		padding: 0.5rem 0.75rem;
		border-bottom: 1px solid var(--border);
		flex-wrap: wrap;
	}

	.entry-sort-chip {
		font-size: 0.75rem;
		padding: 0.2rem 0.55rem;
		border-radius: var(--radius-pill);
		border: 1px solid var(--border);
		background: var(--bg);
		color: var(--text-muted);
		cursor: pointer;
		font-family: var(--font-body);
		transition:
			background var(--duration-fast),
			border-color var(--duration-fast),
			color var(--duration-fast);
	}

	.entry-sort-chip.active {
		background: var(--accent-soft);
		border-color: var(--accent);
		color: var(--accent);
	}

	.entry-sort-dir {
		opacity: 0.7;
	}

	.entry-list {
		display: flex;
		flex-direction: column;
		min-height: 120px;
	}

	.entry-row {
		display: flex;
		align-items: flex-start;
		gap: 0.5rem;
		padding: 0.75rem 1rem;
		background: var(--bg-elevated);
		border-bottom: 1px solid var(--border);
		cursor: grab;
		transition:
			background var(--duration-fast),
			opacity var(--duration-fast);
	}

	.entry-row:last-child {
		border-bottom: none;
	}

	.entry-row:hover {
		background: var(--bg-subtle);
	}
	.entry-row.dragging {
		opacity: 0.4;
	}
	.entry-row.drag-over {
		background: var(--accent-soft);
	}

	.drag-handle {
		color: var(--border);
		flex-shrink: 0;
		margin-top: 0.125rem;
	}

	.entry-info {
		flex: 1;
		min-width: 0;
	}

	.entry-badges {
		display: flex;
		align-items: center;
		gap: 0.375rem;
		margin-bottom: 0.25rem;
	}

	.entry-title {
		font-size: 0.8125rem;
		color: var(--text);
		line-height: 1.4;
	}

	.entry-suite {
		font-size: 0.7rem;
		color: var(--text-muted);
	}

	.exec-locked-banner {
		font-size: 0.8125rem;
		color: var(--text-muted);
		background: var(--bg-subtle);
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		padding: 0.625rem 1rem;
		margin-bottom: 1rem;
	}

	/* ── Suite browser ── */
	.right-panel {
		position: sticky;
		top: calc(56px + 1.5rem);
		height: calc(100vh - 56px - 3rem);
		display: flex;
		flex-direction: column;
		overflow: hidden;
	}

	.suite-browser {
		flex: 1;
		min-height: 0;
		padding: 0.625rem;
		display: flex;
		flex-direction: column;
		gap: 0.25rem;
		overflow-y: auto;
	}

	.browser-suite {
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		overflow: hidden;
		flex-shrink: 0;
	}

	.browser-suite-header {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		width: 100%;
		min-height: 40px;
		padding: 0.5rem 0.75rem;
		background: var(--bg-subtle);
		border: none;
		cursor: pointer;
		text-align: left;
		font-family: var(--font-body);
		transition: background var(--duration-fast);
	}

	.browser-suite-header:hover {
		background: var(--bg);
	}

	.chevron {
		color: var(--text-muted);
		transition: transform var(--duration-fast);
		flex-shrink: 0;
	}

	.chevron.open {
		transform: rotate(90deg);
	}

	.browser-suite-name {
		font-size: 0.8125rem;
		font-weight: 500;
		color: var(--text);
		flex: 1;
	}

	.browser-suite-count {
		font-size: 0.7rem;
		color: var(--text-muted);
	}

	.browser-cases {
		display: flex;
		flex-direction: column;
		gap: 0;
		border-top: 1px solid var(--border);
		max-height: 380px;
		overflow-y: auto;
	}

	.browser-case {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		width: 100%;
		padding: 0.5rem 0.75rem;
		background: var(--bg-elevated);
		border: none;
		border-top: 1px solid var(--border);
		cursor: pointer;
		text-align: left;
		font-family: var(--font-body);
		transition: background var(--duration-fast);
	}

	.browser-case:first-child {
		border-top: none;
	}
	.browser-case:hover {
		background: var(--accent-soft);
	}

	.browser-case-title {
		font-size: 0.8125rem;
		color: var(--text);
		flex: 1;
		min-width: 0;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.browser-empty {
		padding: 0.625rem 0.75rem;
		font-size: 0.75rem;
		color: var(--text-muted);
	}

	/* ── Execute ── */
	.progress-bar-wrap {
		margin-bottom: 1.25rem;
	}

	.progress-stats {
		display: flex;
		align-items: center;
		gap: 1rem;
		margin-bottom: 0.5rem;
	}

	.stat {
		font-size: 0.8125rem;
		font-weight: 500;
	}

	.stat.pass {
		color: var(--pass);
	}
	.stat.fail {
		color: var(--fail);
	}
	.stat.muted {
		color: var(--text-muted);
	}

	.progress-bar {
		height: 6px;
		background: var(--bg-subtle);
		border-radius: var(--radius-pill);
		overflow: hidden;
		display: flex;
	}

	.progress-fill {
		height: 100%;
		border-radius: var(--radius-pill);
		transition: width 0.3s var(--ease-out);
	}

	.progress-fill.pass {
		background: var(--pass);
	}
	.progress-fill.fail {
		background: var(--fail);
	}

	.execute-list {
		display: flex;
		flex-direction: column;
		background: var(--bg-elevated);
		border: 1px solid var(--border);
		border-radius: var(--radius-md);
		overflow: hidden;
	}

	.execute-row {
		background: var(--bg-elevated);
		border-bottom: 1px solid var(--border);
		transition: background var(--duration-fast);
	}

	.execute-row:last-child {
		border-bottom: none;
	}

	.execute-row:hover {
		background: color-mix(in srgb, var(--text-muted) 6%, var(--bg-elevated));
	}

	.execute-row-main {
		display: flex;
		align-items: center;
		gap: 1rem;
		padding: 0.875rem 1rem;
	}

	.exec-info {
		display: flex;
		align-items: flex-start;
		gap: 0.625rem;
		flex: 1;
		min-width: 0;
	}

	.exec-title {
		font-size: 0.875rem;
		font-weight: 500;
		color: var(--text);
		line-height: 1.4;
	}

	.exec-suite {
		font-size: 0.75rem;
		color: var(--text-muted);
	}

	.exec-actions {
		display: flex;
		align-items: center;
		gap: 0.375rem;
		flex-shrink: 0;
	}

	.exec-btns {
		display: flex;
		align-items: center;
		gap: 0.25rem;
		flex-wrap: wrap;
	}

	.exec-btns.locked {
		opacity: 0.45;
	}

	.exec-btn {
		height: 26px;
		padding: 0 0.6rem;
		border-radius: var(--radius-sm);
		border: 1px solid var(--border);
		background: var(--bg);
		cursor: pointer;
		font-size: 0.75rem;
		font-family: var(--font-body);
		font-weight: 500;
		color: var(--text-muted);
		display: flex;
		align-items: center;
		white-space: nowrap;
		transition:
			background var(--duration-fast),
			border-color var(--duration-fast),
			color var(--duration-fast);
	}

	.exec-btn.in-progress:hover,
	.exec-btn.in-progress.active {
		background: var(--accent-soft);
		border-color: var(--accent);
		color: var(--accent);
	}
	.exec-btn.pass:hover {
		background: var(--pass-soft);
		border-color: var(--pass);
		color: var(--pass);
	}
	.exec-btn.fail:hover {
		background: var(--fail-soft);
		border-color: var(--fail);
		color: var(--fail);
	}
	.exec-btn.warn:hover {
		background: var(--warn-soft);
		border-color: var(--warn);
		color: var(--warn);
	}
	.exec-btn.muted:hover {
		background: var(--bg-subtle);
		border-color: var(--text-muted);
		color: var(--text-muted);
	}

	.exec-btn:disabled {
		cursor: not-allowed;
	}
	.exec-btn:disabled:hover {
		background: var(--bg);
		border-color: var(--border);
		color: var(--text-muted);
	}
	.exec-reset:disabled {
		cursor: not-allowed;
		opacity: 0.45;
	}

	.exec-reset {
		height: 26px;
		padding: 0 0.6rem;
		font-size: 0.75rem;
		font-family: var(--font-body);
		color: var(--text-muted);
		background: var(--bg);
		border: 1px solid var(--border);
		border-radius: var(--radius-sm);
		cursor: pointer;
		transition:
			color var(--duration-fast),
			border-color var(--duration-fast);
	}

	.exec-reset:hover {
		color: var(--text);
		border-color: var(--text-muted);
	}

	.exec-assignee-row {
		display: flex;
		align-items: center;
		gap: 0.5rem;
	}

	.exec-assignee-divider {
		height: 1px;
		background: var(--border);
		margin: 0.375rem 0;
	}

	.exec-assignee-name {
		font-size: 0.75rem;
		line-height: 26px;
		color: var(--text-muted);
	}

	.exec-assign-me {
		font-size: 0.7rem;
		font-family: var(--font-body);
		color: var(--accent);
		background: none;
		border: 1px solid var(--accent);
		border-radius: var(--radius-pill);
		padding: 0.1rem 0.5rem;
		cursor: pointer;
		transition: background var(--duration-fast);
	}

	.exec-assign-me:hover {
		background: var(--accent-soft);
	}

	.exec-assign-me:disabled {
		opacity: 0.5;
		cursor: not-allowed;
	}

	.exec-chevron {
		background: none;
		border: none;
		padding: 0.125rem;
		cursor: pointer;
		color: var(--text-muted);
		display: flex;
		align-items: center;
		flex-shrink: 0;
		transition: color var(--duration-fast);
	}

	.exec-chevron:hover {
		color: var(--text);
	}

	/* ── Steps in execute view ── */
	.exec-steps {
		border-top: 1px solid var(--border);
		padding: 0.75rem 1rem;
		display: flex;
		flex-direction: column;
		gap: 0.5rem;
		background: var(--bg-subtle);
	}

	.exec-step {
		display: flex;
		gap: 0.5rem;
		align-items: flex-start;
	}

	.exec-step-num {
		font-size: 0.7rem;
		font-weight: 600;
		color: var(--text-muted);
		width: 20px;
		flex-shrink: 0;
		padding-top: 0.1rem;
	}

	.exec-step-body {
		flex: 1;
	}

	.exec-step-action {
		font-size: 0.8125rem;
		color: var(--text);
		line-height: 1.4;
	}

	.exec-step-data,
	.exec-step-expected {
		font-size: 0.75rem;
		color: var(--text-muted);
		font-family: 'JetBrains Mono', monospace;
		margin-top: 0.2rem;
	}

	.icon-btn {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 26px;
		height: 26px;
		border: none;
		border-radius: var(--radius-sm);
		background: transparent;
		cursor: pointer;
		color: var(--text-muted);
		transition:
			background var(--duration-fast),
			color var(--duration-fast);
		flex-shrink: 0;
	}

	.icon-btn:hover {
		background: var(--bg-subtle);
		color: var(--text);
	}
	.icon-btn.danger:hover {
		background: var(--fail-soft);
		color: var(--fail);
	}

	@media (max-width: 768px) {
		.builder-workspace {
			grid-template-columns: 1fr;
		}

		.right-panel {
			display: none;
		}
	}

	.form-fields {
		display: flex;
		flex-direction: column;
		gap: 0.875rem;
	}
	.modal-actions {
		display: flex;
		gap: 0.5rem;
		padding-top: 0.25rem;
	}
</style>
