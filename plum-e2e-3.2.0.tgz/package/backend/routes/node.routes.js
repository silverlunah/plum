/*
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 */

const express = require('express');
const router = express.Router();
const { authGuard } = require('../middleware/auth');
const { isNodeMode, DEFAULT_PORT } = require('../constants/env');
const nodeExecutionService = require('../services/nodeExecutionService');

// Health check: primary server uses this to confirm the node is reachable
router.get('/ping', authGuard, (req, res) => {
	res.json({ ok: true, mode: process.env.PLUM_MODE || 'server' });
});

// Graceful shutdown for node-mode processes (no-op on the primary server)
router.post('/shutdown', authGuard, (req, res) => {
	if (!isNodeMode()) {
		return res.status(403).json({ error: 'Not a node runner' });
	}
	res.json({ ok: true });
	setTimeout(() => process.exit(0), 200);
});

// Self-restart for node-mode processes: spawns a replacement using this
// process's own env (RUNNER_ID/PORT/NODE_TOKEN), then exits. The replacement
// binds the same port, retrying past the brief EADDRINUSE window left by this
// process shutting down (see the listen retry in server.js).
router.post('/restart', authGuard, (req, res) => {
	if (!isNodeMode()) {
		return res.status(403).json({ error: 'Not a node runner' });
	}
	const id = process.env.RUNNER_ID;
	if (!id) {
		return res.status(400).json({ error: 'Runner has no RUNNER_ID, cannot self-restart' });
	}
	res.json({ ok: true });
	setTimeout(() => {
		const { startNode } = require('../lib/runnerProcess');
		startNode({ id, port: process.env.PORT || DEFAULT_PORT, token: process.env.NODE_TOKEN });
		process.exit(0);
	}, 200);
});

// The primary calls this after PLUM_NODE_SECRET is regenerated, so the copy this
// machine's `plum node` CLI reads (~/.plum/nodes/<name>/.plum-node.json) stays
// current. Matched to this process by RUNNER_ID.
router.post('/node-secret', authGuard, (req, res) => {
	if (!isNodeMode()) return res.status(403).json({ error: 'Not a node runner' });
	const { secret } = req.body;
	const id = process.env.RUNNER_ID;
	if (!secret || !id) return res.status(400).json({ error: 'secret and RUNNER_ID are required' });
	const nodeRegister = require('../lib/nodeRegister');
	let updated = 0;
	for (const name of nodeRegister.listNodeNames()) {
		const cfg = nodeRegister.loadNodeByName(name);
		if (String(cfg.id) === String(id)) {
			nodeRegister.saveNodeByName(name, { ...cfg, nodeSecret: secret });
			updated++;
		}
	}
	res.json({ ok: true, updated });
});

// Start a remote test job
router.post('/execute', authGuard, (req, res) => {
	const jobId = nodeExecutionService.startJob(req.body);
	res.json({ jobId, status: 'started' });
});

// Stop a running job (primary server relays a user's cancel)
router.post('/cancel/:jobId', authGuard, (req, res) => {
	const ok = nodeExecutionService.cancelJob(req.params.jobId);
	if (!ok) return res.status(404).json({ error: 'Job not found' });
	res.json({ ok: true });
});

// Fetch the final report content after a job completes
router.get('/report/:jobId', authGuard, (req, res) => {
	const job = nodeExecutionService.getJob(req.params.jobId);
	if (!job) return res.status(404).json({ error: 'Job not found' });
	if (!job.reportContent) return res.status(404).json({ error: 'Report not ready' });
	res.json({ content: job.reportContent, meta: job.meta });
});

// Poll job status and streamed logs
router.get('/execute/:jobId', authGuard, (req, res) => {
	const offset = parseInt(req.query.offset || '0', 10);
	const rrwebOffset = parseInt(req.query.rrwebOffset || '0', 10);
	const result = nodeExecutionService.pollJob(req.params.jobId, offset, rrwebOffset);
	if (!result) return res.status(404).json({ error: 'Job not found' });
	res.json(result);
});

module.exports = router;
