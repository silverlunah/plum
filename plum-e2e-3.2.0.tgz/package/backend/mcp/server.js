/*
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 */

/**
 * Plum MCP Server
 *
 * Exposes Plum's Test Repository and test runner to any MCP-compatible AI client
 * over Streamable HTTP (see routes/mcp.routes.js for the transport wiring). Tool
 * handlers call the same services the REST routes use directly, this module
 * runs in-process inside the Plum backend, not as a separate subprocess.
 */

const path = require('path');

// Use absolute paths to bypass the SDK's wildcard export mapping
const sdkCjs = path.resolve(
	__dirname,
	'..',
	'node_modules',
	'@modelcontextprotocol',
	'sdk',
	'dist',
	'cjs'
);
const { McpServer } = require(path.join(sdkCjs, 'server', 'mcp.js'));
const { z } = require('zod');
const { TRIGGER_TYPE } = require('../constants/triggers');
const { JOB_STATUS } = require('../constants/jobStatus');
const testSuiteService = require('../services/testSuiteService');
const testCaseService = require('../services/testCaseService');
const triggerService = require('../services/triggerService');
const reportService = require('../services/reportService');
const exportService = require('../services/exportService');
const userService = require('../services/userService');
const projectService = require('../services/projectService');
const settingsService = require('../services/settingsService');

// ---------------------------------------------------------------------------
// Polling helper for test runs
// ---------------------------------------------------------------------------

async function pollJob(projectId, jobId, { maxMs = 600_000, intervalMs = 5_000 } = {}) {
	const deadline = Date.now() + maxMs;
	while (Date.now() < deadline) {
		await new Promise((r) => setTimeout(r, intervalMs));
		const job = await triggerService.getJob(jobId, projectId);
		if (job && job.status !== JOB_STATUS.RUNNING) return job;
	}
	return { status: 'timeout', jobId };
}

// ---------------------------------------------------------------------------
// Report summary helper
// ---------------------------------------------------------------------------

function summariseReport(report) {
	const features = report.features ?? report.content?.features ?? [];
	const allScenarios = features.flatMap((f) => f.scenarios ?? []);
	const total = allScenarios.length;
	const passed = allScenarios.filter((s) => s.status === 'passed').length;
	const failed = allScenarios.filter((s) => s.status === 'failed').length;

	const failedDetails = allScenarios
		.filter((s) => s.status === 'failed')
		.map((s) => {
			const failedStep = (s.steps ?? []).find((st) => st.status === 'failed');
			return {
				scenario: s.name,
				feature: features.find((f) => (f.scenarios ?? []).includes(s))?.name ?? '',
				failedStep: failedStep?.name ?? '',
				error: failedStep?.error ?? ''
			};
		});

	return {
		id: report.id,
		status: report.status,
		browser: report.browser,
		tags: report.tags,
		createdAt: report.createdAt,
		summary: { total, passed, failed },
		failures: failedDetails
	};
}

// ---------------------------------------------------------------------------
// Server setup
// ---------------------------------------------------------------------------

/**
 * Builds a fresh McpServer with all Plum tools registered, closing over the
 * authenticated user for this request (see routes/mcp.routes.js, a new
 * server/transport pair is created per request in stateless mode).
 */
function createMcpServer({ userId, userName, projectId, role, viaMcp, apiKeyKind }) {
	const server = new McpServer({
		name: 'plum',
		version: '1.0.0'
	});

	// Org-wide tools need the instance key, a per-project key stays scoped even
	// when the owner holds it.
	const assertAccountAdmin = () => {
		if (apiKeyKind !== 'instance') {
			throw new Error('This tool needs the instance API key (PLUM_MCP_KEY).');
		}
	};

	// -- Test Repository: Suites -----------------------------------------------

	server.tool(
		'list_test_suites',
		'List all test suites in the Plum Test Repository.',
		{
			page: z.number().int().positive().optional().describe('Page number (default 1)'),
			limit: z
				.number()
				.int()
				.positive()
				.max(100)
				.optional()
				.describe('Results per page (default 20)')
		},
		async ({ page = 1, limit = 20 }) => {
			const data = await testSuiteService.getAll(projectId, { page, limit });
			return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
		}
	);

	server.tool(
		'get_test_suite',
		'Get a test suite by ID, including all its test cases.',
		{
			suiteId: z.string().describe('The suite ID (e.g. the database UUID, not the displayId)')
		},
		async ({ suiteId }) => {
			const suite = await testSuiteService.getById(projectId, suiteId);
			if (!suite) throw new Error('Suite not found');
			return { content: [{ type: 'text', text: JSON.stringify(suite, null, 2) }] };
		}
	);

	server.tool(
		'create_test_suite',
		'Create a new test suite in the Plum Test Repository.',
		{
			name: z.string().min(1).describe('Suite name, e.g. "User Authentication"'),
			description: z.string().optional().describe('What this suite covers'),
			priority: z
				.enum(['Critical', 'High', 'Medium', 'Low'])
				.optional()
				.describe('Suite priority (default Medium)')
		},
		async ({ name, description, priority }) => {
			const suite = await testSuiteService.create(projectId, {
				name,
				description,
				priority,
				createdById: userId,
				viaMcp
			});
			return { content: [{ type: 'text', text: JSON.stringify(suite, null, 2) }] };
		}
	);

	server.tool(
		'update_test_suite',
		"Update a test suite's name, description, or priority. Only the fields provided are changed.",
		{
			suiteId: z.string().describe('UUID of the suite to update'),
			name: z.string().min(1).optional(),
			description: z.string().optional(),
			priority: z.enum(['Critical', 'High', 'Medium', 'Low']).optional()
		},
		async ({ suiteId, name, description, priority }) => {
			const suite = await testSuiteService.update(projectId, suiteId, {
				name,
				description,
				priority
			});
			return { content: [{ type: 'text', text: JSON.stringify(suite, null, 2) }] };
		}
	);

	server.tool(
		'delete_test_suite',
		'Permanently delete a test suite and all of its test cases. This cannot be undone.',
		{
			suiteId: z.string().describe('UUID of the suite to delete')
		},
		async ({ suiteId }) => {
			await testSuiteService.remove(projectId, suiteId);
			return { content: [{ type: 'text', text: `Suite ${suiteId} deleted.` }] };
		}
	);

	// -- Test Repository: Cases -------------------------------------------------

	server.tool(
		'create_test_case',
		'Create a test case inside an existing test suite.',
		{
			suiteId: z.string().describe('UUID of the parent test suite'),
			title: z
				.string()
				.min(1)
				.describe('Case title, e.g. "User can log in with valid credentials"'),
			description: z.string().optional().describe('Scope, assumptions, or edge cases'),
			priority: z.enum(['Critical', 'High', 'Medium', 'Low']).optional()
		},
		async ({ suiteId, title, description, priority }) => {
			const testCase = await testCaseService.create(projectId, {
				suiteId,
				title,
				description,
				priority,
				createdById: userId,
				viaMcp
			});
			return { content: [{ type: 'text', text: JSON.stringify(testCase, null, 2) }] };
		}
	);

	server.tool(
		'get_test_case',
		'Get a test case by ID, including its manual steps and recent execution history.',
		{
			caseId: z.string().describe('UUID of the test case')
		},
		async ({ caseId }) => {
			const testCase = await testCaseService.getById(projectId, caseId);
			if (!testCase) throw new Error('Test case not found');
			return { content: [{ type: 'text', text: JSON.stringify(testCase, null, 2) }] };
		}
	);

	server.tool(
		'update_test_case',
		"Update a test case's title, description, or priority. Only the fields provided are changed.",
		{
			caseId: z.string().describe('UUID of the test case to update'),
			title: z.string().min(1).optional(),
			description: z.string().optional(),
			priority: z.enum(['Critical', 'High', 'Medium', 'Low']).optional()
		},
		async ({ caseId, title, description, priority }) => {
			const testCase = await testCaseService.update(projectId, caseId, {
				title,
				description,
				priority
			});
			return { content: [{ type: 'text', text: JSON.stringify(testCase, null, 2) }] };
		}
	);

	server.tool(
		'delete_test_case',
		'Permanently delete a test case and its steps. This cannot be undone.',
		{
			caseId: z.string().describe('UUID of the test case to delete')
		},
		async ({ caseId }) => {
			await testCaseService.remove(projectId, caseId);
			return { content: [{ type: 'text', text: `Test case ${caseId} deleted.` }] };
		}
	);

	server.tool(
		'set_test_steps',
		'Set (replace) the manual test steps for a test case. Each step has an action, optional test data, and optional expected output.',
		{
			caseId: z.string().describe('UUID of the test case'),
			steps: z
				.array(
					z.object({
						action: z.string().describe('What the tester does'),
						testData: z.string().optional().describe('Specific input or data to use'),
						expectedOutput: z.string().optional().describe('What should happen')
					})
				)
				.describe('Ordered list of steps. Replaces any existing steps.')
		},
		async ({ caseId, steps }) => {
			const saved = await testCaseService.upsertSteps(projectId, caseId, steps);
			return { content: [{ type: 'text', text: JSON.stringify(saved, null, 2) }] };
		}
	);

	// -- Test Runner ------------------------------------------------------------

	server.tool(
		'run_tests',
		[
			'Trigger a Plum test run and wait for results. Returns a pass/fail summary.',
			'',
			'For PR testing: pass baseUrl to override the default BASE_URL for this run only.',
			'If the app runs on localhost, use host.docker.internal instead (e.g. http://host.docker.internal:3000)',
			'so the Plum Docker container can reach it.',
			'',
			'Tag filter examples: "@login" "@TC-001 or @TC-002" "@smoke and not @slow"',
			'Leave tag blank to run all tests.'
		].join('\n'),
		{
			tag: z
				.string()
				.optional()
				.describe('Cucumber tag expression to filter scenarios. Leave blank to run all.'),
			browser: z
				.enum(['chromium', 'firefox'])
				.optional()
				.describe('Browser to run tests in (default chromium)'),
			workers: z
				.number()
				.int()
				.positive()
				.max(10)
				.optional()
				.describe('Number of parallel workers (default 1)'),
			baseUrl: z
				.string()
				.url()
				.optional()
				.describe(
					'Override the app URL for this run only. Use host.docker.internal instead of localhost.'
				),
			testRunId: z
				.string()
				.optional()
				.describe(
					'Link results to a Plum Test Run. Automated entries will be marked pass/fail automatically.'
				)
		},
		async ({ tag, browser, workers, baseUrl, testRunId }) => {
			const jobId = await triggerService.startRun({
				projectId,
				tag,
				browser,
				workers,
				baseUrl,
				testRunId,
				trigger: TRIGGER_TYPE.MCP,
				startedBy: userName
			});

			const job = await pollJob(projectId, jobId);

			if (job.status === 'timeout') {
				return {
					content: [
						{
							type: 'text',
							text: `Tests are still running after 10 minutes. Job ID: ${jobId}\nUse get_run_status("${jobId}") to check later.`
						}
					]
				};
			}

			if (!job.reportId) {
				return {
					content: [
						{
							type: 'text',
							text: `Tests finished with exit code ${job.exitCode} but no report was found. The run may have been cancelled or produced no output.`
						}
					]
				};
			}

			const report = await reportService.getReportDetail(projectId, job.reportId);
			const summary = summariseReport(report);

			const lines = [
				`Status: ${summary.status?.toUpperCase()}`,
				`Scenarios: ${summary.summary.total} total, ${summary.summary.passed} passed, ${summary.summary.failed} failed`,
				`Browser: ${summary.browser}`,
				`Tags: ${summary.tags || 'all tests'}`,
				''
			];

			if (summary.failures.length > 0) {
				lines.push('Failed scenarios:');
				for (const f of summary.failures) {
					lines.push(`  ✗ ${f.feature} › ${f.scenario}`);
					if (f.failedStep) lines.push(`    Step: ${f.failedStep}`);
					if (f.error) lines.push(`    Error: ${f.error.split('\n')[0]}`);
				}
			} else {
				lines.push('All scenarios passed.');
			}

			lines.push('', `Report ID: ${summary.id}`);

			return { content: [{ type: 'text', text: lines.join('\n') }] };
		}
	);

	server.tool(
		'get_run_status',
		'Check the status of a test run that was started with run_tests. Returns status, exit code, and report ID when done.',
		{
			jobId: z.string().uuid().describe('Job ID returned by run_tests')
		},
		async ({ jobId }) => {
			const job = await triggerService.getJob(jobId, projectId);
			if (!job) throw new Error('Job not found');
			return { content: [{ type: 'text', text: JSON.stringify(job, null, 2) }] };
		}
	);

	// -- Reports ----------------------------------------------------------------

	server.tool(
		'list_reports',
		'List recent Plum test reports.',
		{
			limit: z
				.number()
				.int()
				.positive()
				.max(50)
				.optional()
				.describe('Number of reports (default 10)')
		},
		async ({ limit = 10 }) => {
			const data = await reportService.getReports(projectId, { limit });
			return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
		}
	);

	server.tool(
		'get_report_summary',
		'Get a human-readable summary of a Plum test report, including a list of failed scenarios.',
		{
			reportId: z.number().int().describe('Numeric report ID')
		},
		async ({ reportId }) => {
			const detail = await reportService.getReportDetail(projectId, reportId);
			if (!detail) throw new Error('Report not found');
			const summary = summariseReport(detail);
			const lines = [
				`Report #${summary.id}, ${summary.status?.toUpperCase()}`,
				`Date: ${summary.createdAt}`,
				`Browser: ${summary.browser}`,
				`Tags: ${summary.tags || 'all tests'}`,
				`Scenarios: ${summary.summary.total} total, ${summary.summary.passed} passed, ${summary.summary.failed} failed`,
				''
			];
			if (summary.failures.length > 0) {
				lines.push('Failures:');
				for (const f of summary.failures) {
					lines.push(`  ✗ ${f.feature} › ${f.scenario}`);
					if (f.failedStep) lines.push(`    Step: ${f.failedStep}`);
					if (f.error) lines.push(`    Error: ${f.error.split('\n')[0]}`);
				}
			} else {
				lines.push('All scenarios passed.');
			}
			return { content: [{ type: 'text', text: lines.join('\n') }] };
		}
	);

	server.tool(
		'get_report_scenario_detail',
		[
			'Get full per-scenario, per-step detail for a Plum test report, the data needed to diagnose',
			"and self-heal a failing test: every step's status, duration, and full error message.",
			'',
			'Use get_report_logs for the raw test-run stdout/stderr.'
		].join('\n'),
		{
			reportId: z.number().int().describe('Numeric report ID'),
			onlyFailed: z
				.boolean()
				.optional()
				.describe('Only include scenarios with a failed step (default true)')
		},
		async ({ reportId, onlyFailed = true }) => {
			const detail = await reportService.getReportDetail(projectId, reportId);
			if (!detail) throw new Error('Report not found');
			const features = detail.features ?? [];

			const scenarios = features.flatMap((feature) =>
				(feature.scenarios ?? [])
					.filter((s) => !onlyFailed || s.status === 'failed')
					.map((s) => ({
						feature: feature.name,
						scenario: s.name,
						tags: s.tags ?? [],
						status: s.status,
						duration: s.duration,
						steps: (s.steps ?? []).map((st) => ({
							keyword: st.keyword,
							name: st.name,
							status: st.status,
							duration: st.duration,
							error: st.error ?? null
						}))
					}))
			);

			return {
				content: [{ type: 'text', text: JSON.stringify({ reportId, scenarios }, null, 2) }]
			};
		}
	);

	server.tool(
		'get_report_logs',
		'Get the raw stdout/stderr log output captured during a Plum test run, tagged per runner. ' +
			'Useful for diagnosing failures with no clear step-level error (crashes, timeouts, setup errors).',
		{
			reportId: z.number().int().describe('Numeric report ID'),
			tail: z
				.number()
				.int()
				.positive()
				.optional()
				.describe('Only return the last N lines (default: full log)')
		},
		async ({ reportId, tail }) => {
			const detail = await reportService.getReportDetail(projectId, reportId);
			if (!detail) throw new Error('Report not found');
			let logs = detail.logs ?? '';
			if (tail) {
				logs = logs.split('\n').slice(-tail).join('\n');
			}
			return { content: [{ type: 'text', text: logs || '(no logs captured for this report)' }] };
		}
	);

	// -- Exports --------------------------------------------------------------

	server.tool(
		'export_test_cases',
		'Export test cases as CSV (one row per step) or JSON. Scope: the whole repository, one suite, or one test run (a run also carries each case’s recorded result). The JSON form can be re-imported.',
		{
			format: z.enum(['csv', 'json']).describe('csv or json'),
			scope: z.enum(['all', 'suite', 'run']).optional().describe('Default: all'),
			id: z.string().optional().describe('Suite or run id, required when scope is "suite" or "run"')
		},
		async ({ format, scope = 'all', id }) => {
			if ((scope === 'suite' || scope === 'run') && !id) {
				throw new Error(`scope "${scope}" needs an id`);
			}
			const data = await exportService.buildTestCaseExport(projectId, scope, {
				suiteId: id,
				runId: id
			});
			if (!data) throw new Error('Nothing found for that scope/id');
			const text =
				format === 'csv' ? exportService.testCaseCsv(data) : JSON.stringify(data, null, 2);
			return { content: [{ type: 'text', text }] };
		}
	);

	server.tool(
		'export_report',
		'Export a Plum test report as CSV (one row per step) or a minimal JSON summary suitable for sharing.',
		{
			reportId: z.number().int().describe('Numeric report ID'),
			format: z.enum(['csv', 'json']).describe('csv or json')
		},
		async ({ reportId, format }) => {
			const data = await exportService.buildReportExport(projectId, reportId);
			if (!data) throw new Error('Report not found');
			const text = format === 'csv' ? exportService.reportCsv(data) : JSON.stringify(data, null, 2);
			return { content: [{ type: 'text', text }] };
		}
	);

	// -- Account administration ------------------------------------------------
	// Deleting a user or a project is deliberately not here, a human does that
	// in the UI.

	const asJson = (data) => ({ content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] });

	server.tool('list_users', 'List every Plum account with its role.', {}, async () => {
		assertAccountAdmin();
		return asJson(await userService.getAll());
	});

	server.tool(
		'create_user',
		'Create a Plum account. The person can sign in immediately with the password you set.',
		{
			name: z.string().min(1),
			email: z.string().email(),
			password: z.string().min(8).describe('At least 8 characters'),
			role: z.enum(['owner', 'admin', 'user']).optional().describe('Default: user')
		},
		async ({ name, email, password, role = 'user' }) => {
			assertAccountAdmin();
			return asJson(await userService.createUser({ name, email, password, role }));
		}
	);

	server.tool(
		'update_user',
		'Change a Plum account’s name, email or role. Does not set passwords.',
		{
			userId: z.string().describe('The account id (cuid), not the email'),
			name: z.string().min(1).optional(),
			email: z.string().email().optional(),
			role: z.enum(['owner', 'admin', 'user']).optional()
		},
		async ({ userId, name, email, role }) => {
			assertAccountAdmin();
			const result = await userService.updateUser(userId, { name, email, role });
			if (!result.ok) throw new Error(result.error);
			return asJson(result.user);
		}
	);

	server.tool(
		'list_projects',
		'List every project in the organisation with its slug and member count.',
		{},
		async () => {
			assertAccountAdmin();
			return asJson(await projectService.listAll());
		}
	);

	server.tool(
		'create_project',
		'Create a project. Its slug (folder + API identity) is derived from the name and never changes.',
		{
			name: z.string().min(1)
		},
		async ({ name }) => {
			assertAccountAdmin();
			return asJson(await projectService.create({ name }));
		}
	);

	server.tool(
		'update_project',
		'Change a project’s name, logo, timezone or retry count. The slug never changes.',
		{
			projectId: z.number().int().describe('Numeric project id'),
			name: z.string().min(1).optional(),
			logoUrl: z.string().optional(),
			timezone: z.string().optional().describe('IANA name, e.g. "Asia/Manila"'),
			maxRetries: z.number().int().min(0).optional()
		},
		async ({ projectId: id, name, logoUrl, timezone, maxRetries }) => {
			if (role !== 'owner' && role !== 'admin') {
				throw new Error('Updating project settings needs an admin or owner key.');
			}
			// A scoped key stays on its own project; only the instance key roams.
			if (apiKeyKind !== 'instance' && id !== projectId) {
				throw new Error(`This key is scoped to project ${projectId}.`);
			}
			return asJson(
				await settingsService.updateProject(id, { name, logoUrl, timezone, maxRetries })
			);
		}
	);

	return server;
}

module.exports = { createMcpServer };
