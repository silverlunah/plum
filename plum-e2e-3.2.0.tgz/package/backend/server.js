/*
 * This file is part of Plum.
 * Licensed under the MIT License. See LICENSE file in the project root for details.
 */

const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const { PLUM_MODE_NODE, DEFAULT_PORT } = require('./constants/env');

// Resolve the JWT + node-control secrets before anything that uses them loads.
if (process.env.PLUM_MODE !== PLUM_MODE_NODE) {
	const appSecret = require('./lib/appSecret');
	appSecret.ensureJwtSecret();
	appSecret.ensureNodeSecret();
}

const app = require('./app');
const {
	ensureTestsDir,
	attachListenRetry,
	wireRealtimeServices,
	initCronServices,
	bootstrapMcpKey,
	onServerListening
} = require('./lib/serverBootstrap');

// Runner nodes receive their test files from dispatched jobs; the main
// server expects them to already be mounted on disk.
const testsDir = path.resolve(process.cwd(), 'tests');

// Node/runner mode strips out everything that only makes sense on the main
// server (cron, MCP, socket.io, file watching).
const isNodeMode = process.env.PLUM_MODE === PLUM_MODE_NODE;

const port = parseInt(process.env.PORT || DEFAULT_PORT, 10);

// The underlying HTTP server, shared by Express and Socket.io.
const server = http.createServer(app);

// Real-time transport for live test output, the rrweb stream, and run status.
// Same pin as the HTTP layer: a deployment that restricts origins should not have
// the websocket accept everything.
function allowedOrigins() {
	const list = (process.env.PLUM_ALLOWED_ORIGINS || '')
		.split(',')
		.map((o) => o.trim())
		.filter(Boolean);
	return list.length > 0 ? list : '*';
}

const io = new Server(server, { cors: { origin: allowedOrigins() } });

// Sockets stream live test output and DOM recordings (which can hold
// credentials), signed-in users only. Per-project scoping is in socketHandler.
if (!isNodeMode) {
	const { verifyToken } = require('./services/userService');
	io.use((socket, next) => {
		try {
			socket.data.user = verifyToken(socket.handshake.auth?.token);
			next();
		} catch {
			next(new Error('unauthorized'));
		}
	});
}

async function start() {
	// A node runs arbitrary test code, refuse to start without the token that gates it.
	if (isNodeMode && !process.env.NODE_TOKEN) {
		console.error('❌ Node mode requires NODE_TOKEN, start nodes with `plum node start`.');
		process.exit(1);
	}

	if (isNodeMode) {
		// A previous process may have exited with report files still pending the
		// in-memory timer that deletes them.
		require('./services/nodeExecutionService').sweepStaleJobArtifacts();
	}

	// Confirm the tests directory is in place before doing anything else.
	ensureTestsDir(testsDir, isNodeMode);

	// Survive the brief EADDRINUSE window a self-restart can hit.
	attachListenRetry(server, port);

	// Connect socket.io to the runner/cron services (a no-op in node mode).
	const {
		cronService,
		backupCronService,
		activityRetentionService,
		reportRetentionService,
		runQueueService
	} = wireRealtimeServices(io, isNodeMode);

	// Start the scheduled test, backup, and log/report-prune cron jobs.
	await initCronServices(
		cronService,
		backupCronService,
		activityRetentionService,
		reportRetentionService
	);

	// Reconcile the persisted run queue: clear rows left "running" by a crash,
	// then resume anything still queued.
	if (runQueueService) await runQueueService.init(io);

	// Load the saved MCP API key into the environment for the MCP server.
	await bootstrapMcpKey(isNodeMode);

	// Begin accepting connections, then run mode-specific startup work.
	server.listen(port, () => onServerListening({ port, io, testsDir, isNodeMode }));
}

start().catch((err) => {
	console.error('Failed to start server:', err);
	process.exit(1);
});
